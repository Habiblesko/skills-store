---
name: curiosity-loop
description: "Use to auto-iterate an engagement without re-prompting."
author: c0lonello, Hermes Agent
license: MIT
version: 1.0.2
---

# Curiosity Loop — o agente se auto-prompta, o operador só destrava

Substituto do trabalho manual de "escrever e mandar prompt toda hora". Três
peças: (1) protocolo por-prompt na sessão, (2) estado transacional por
engagement, (3) cron sweeper que trabalha sozinho nas horas mortas. Policy de
impacto mora NO EXECUTOR (código), não na boa vontade do prompt.

## Peças

- `~/tools/T3MP3ST/loop_state.py` — estado por engagement
  (`~/engagement-*/loop/state.json`, lockf+escrita atômica).
- `~/tools/T3MP3ST/loop_decide.py` — planejador: lê state, chama
  codex gpt-5.6-sol (fallback automático claude-sonnet via OAuth quando o
  filtro cyber-risk da OpenAI barra), valida JSON, filtra impacto e — REGRA
  DO OPERADOR (13/09): TODO plano aceito passa por panel_mas.py ADVERSARIAL
  ANTES de gravar no state (gpt-5.6 draftera, MAS critica, Hermes vota junto).
  Painel mudo/timeout = fail-closed, plano retido, state intocado.
  Escapatória só p/ teste: LOOP_SKIP_MAS=1. Fail-closed geral: sem JSON
  válido → INCONCLUSIVO + bruto salvo.
- Gate Protocolo D: `proto_d_gate.py` (já existente) decide MAS/debate por turno.

## Protocolo POR-PROMPT (o que o agente faz a cada turno de engagement)

1. `python3 ~/tools/T3MP3ST/loop_state.py get <eng> --summary` — restaura o
   contexto real COMPACTO (contadores, ações abertas, claims vivas, barreiras,
   awaiting_operator, tail do log). ~96% menor que o dump cru — cabe em modelo
   de loop rápido/barato sem estourar contexto. Só use `get <eng>` cru (sem
   `--summary`) quando precisar de um item específico já identificado pelo id no
   resumo. Nunca confiar na memória da conversa.
2. Se o turno envolve decidir próximo passo e a fila está vazia/estagnada:
   `python3 loop_decide.py decide <eng>` → executa as `accepted` (passive /
   verification) AGORA, na sessão.
3. Ao declarar QUALQUER conclusão: registrar em `explored` com `evidence:` (caminho
   apontado) e `depth`. Ao dizer "explorei tudo": OBRIGATÓRIO
   `loop_state.py exhaust <eng>` — se `ok:false`, está PROIBIDO afirmar fim;
   interrogar item-por-item os problems e requeue-los como ações. Duvida
   remanescente → `panel_mas.py` adversarial ANTES do veredito (Protocolo D).
4. Ações `requires_operator` → fila `awaiting_operator` + pedido único e
   concreto ao operador ("preciso X para destravar Y, urgência Z"). Nunca
   perseguir disponibilidade imediata, exceto se for a ÚNICA decisão correta
   — aí exigir na hora, com porquê.
5. Ao terminar lote de ações: `complete <id>`; erro: `fail <id> "motivo"` (3x
   → morre e vira claim unverified, nunca retry infinito).
   GUARD 02/10 (essity): `complete` RECUSA ação cujo `expected_evidence` declarado
   não existe no disco (globs `*` verificados; placeholders `<date>`/XXXX pulados;
   escape `--force-evidence` loga COMPLETE-FORCED). Caso real: sessão de fallback
   gemma-4 completou checkNameAvailability (exige credencial Azure inexistente)
   "via dns-recheck público" e ainda despausou o state sem decide. Complete é só
   para trabalho EXECUTADO — ação que exige algo que você não tem (credencial/GO)
   fica open, nunca complete por evidência-proxi. NUNCA despausar state pausado
   por exaustão sem novo decide ou destravador real do operador.

## Sweeper desacompanhado (cron: job "Curiosity Loop Sweeper")

A cada 10min em sessão fresca: `loop_state.py list` → para cada engagement não
pausado: `sweep --k 3` (BATCH K, GO ALL 30/09: retorna `{"batch":[...]}` com até
3 ações elegíveis já filtradas por kind/attempts — K=1 emite a ação crua, formato
histórico). Execute TODAS do batch sequencialmente NO MESMO TICK, evidência por
ação (`complete/fail` cada). Regra de batch: no máx 1 `kind=impact` por batch —
blast radius de write permanece 1/tick/eng. `sweep` sem `--k` = comportamento
original de 1 ação. Notificar (Telegram) SOMENTE em: sinal novo com evidência,
destravador de operador urgente, ou auto-pause. Ciclo vazio = silêncio.
Budget: LOOP_DAILY_BUDGET ciclos/dia por engagement (default 24).

### Auto-continua sem GO (operador 02/10)
Fila automatizável vazia NÃO significa fim — e NÃO deve mais exigir que o
operador digite GO / `set paused false` para o loop seguir explorando. O
`sweep` agora decide por `exhaustion_problems(data)` (helper em loop_state.py,
reusado pelo comando `exhaust`):
- **Há planner_fuel** (claims sem prova, superfícies rasas/sem evidência — tudo
  que NÃO é "acao automatizavel já aberta") → `sweep` retorna
  `{"none":"queue_empty_but_not_exhausted","action":"run_decide","planner_fuel":[...]}`
  e zera `noop_streak`. O sweeper roda `loop_decide.py decide <eng>` NO MESMO
  TICK (gera deepen/verification novos), re-sweep e executa. NUNCA pausa, nunca
  espera GO enquanto houver ângulo. O loop se auto-alimenta.
- **Exaustão REAL certificada** (planner_fuel vazio = só resta operator-gated) →
  só aí incrementa noop; aos 3, soft-pause (`paused_reason` reabrível por novo
  decide). Esse é o único caso em que pausar é correto.
- `{"none":"decide_in_flight"}` → outro decide já roda; não duplicar.
REGRA DE SEGURANÇA: o GO foi removido SÓ para exploração automatizável
(passive/verification/impact-em-conta-própria com allow_impact). Red-lines
(submit H1, OTP, captcha, link de email, login humano, dado de terceiro)
SEGUEM 100% operator-gated — jamais auto.

## Status de fase no Telegram (regra operador 13/09)

`loop_status.py [eng]` deriva a FASE do state (nunca palpite): WAITING-ACCOUNT /
RECON / TESTING / VALIDATING / AWAITING-OPERATOR / EXHAUSTED / PAUSED + o que
esta tentando agora + ✔/✘ por tentativa (linhas que complete/fail gravam no
log) + contadores (claims duvidosas, fila auto, travadas no operador).
`loop_status.py report` envia tudo ao telegram:h0st.
Cada executor anexa o bloco de status do SEU eng no fim de todo turno que
executou algo; ocioso manda 1 coracao/dia; NUNCA 2 status/dia por eng.

## Vault de sessoes (persistencia de login entre ciclos — operador 13/09)
Ferramentas: `~/tools/sessions/harvest_sessions.py [elastic|wolt|all]` (puxa
cookies+localStorage dos Chromes dedicados :9222/:9223 -> `~/.hermes/session-vault/*.json`, 0600)
e `~/tools/sessions/load_session.py` (escreve o cookie-header/token nos paths
que os scripts de engagement usam: `/tmp/elastic_cookie.txt`, `/tmp/wolt_bearer.txt`).
ROTOBRA no executor de TODA sessao autenticada: PRIMEIRO `load_session.py <eng>`
(e falhou -> so entao pedir re-login ao operador); ULTIMO ato do turno,
depois de qualquer navegacao logada, `harvest_sessions.py <eng>` para o vault
nunca ficar obsoleto. Um login OTP valido dura enquanto o vault respirar.
PITFALL (13/09, Elastic): harvest_sessions.py cai no fallback "primeira aba
de pagina" quando nenhuma aba bate o dominio-alvo — se o Chrome dedicado
estava em outro site na hora da colheita, o vault e SOBRESCRITO com cookies
de terceiros (o vault elastic virou cookies do Box). Defesa: antes de
declarar "sessao morta", confirmar que o vault tem cookies DO DOMINIO-ALVO
(nem presente = provavel colheita errada, nao morte); e nunca colher com o
tab fora do dominio-alvo — navegar o tab de volta primeiro. O loader
passar 401 com vault aparentemente fresco = checar dominio dos cookies antes
de pedir OTP ao operador.

## Higiene de abas / RAM (regra operador 24/09)
Uma aba só fecha quando há 100% de certeza de que NÃO servirá nenhuma tarefa
FUTURA — NÃO ao terminar a tarefa atual. Aba logada/app = valor futuro (o login
serve pros próximos ciclos) → MANTER. Lixo certo (fechar): duplicatas de URL
exata, `about:blank`/newtab de sobra, e abas de login/redirect mortas
empilhadas (manter EXATAMENTE 1 login vivo por host, p/ relogin/OTP futuro).
Ferramenta: `python3 ~/tools/chrome-eng/tab_gc.py <porta> [--keep-substr S] [--dry-run]`
(usa CDP `Target.closeTarget`; o endpoint HTTP `/json/close` não é confiável no
Chrome 15x). Rodar no INÍCIO de cada tick de loop que usa browser e após
sequências de relogin (que empilham abas `/login`). Validado 24/09: 11 abas
Elastic (10 `/login` dup) → 1. Fechar sempre via CDP/`chrome-close.py`, nunca kill.

## Contrato duro de CDP — nunca criar abas

Nos Chromes dedicados, primeiro reutilize a `type=page` já associada ao hostname
alvo: conecte pelo `webSocketDebuggerUrl`. ATENÇÃO (06-11/10/2026, Chrome 15x):
`Page.navigate` em :9222 morre em WebSocketTimeoutException — navegação só via
JS `location.href` + Runtime.evaluate sobre a aba existente (receita validada:
`relogin_9222_v2.py` do elastic), reconectando o WS após cada navegação;
navegar via location.href NÃO re-renderiza SPA React com nova query-string
(inner/text velho = leitura falsa) — para conteúdo por-filtro use URL de página
real (ex.: `hackerone.com/<slug>/hacktivity`). Se não
existir página daquele hostname, é permitido criar EXATAMENTE UMA aba de trabalho
com `~/engagement-stripe/tools/cdp_eval_port.py <porta> <url> <js>`; ela passa a
ser reutilizada nos próximos ticks. Nunca crie uma segunda aba enquanto já houver
uma página daquele hostname. `browser_exec`, `new_tab`, `window.open` e harnesses
que criem targets continuam proibidos. Antes e depois de qualquer sequência CDP,
rode `tab_gc.py <porta>`; mantenha páginas logadas e feche somente lixo
certo/duplicatas exatas.

## Bootstrap singleton do Chrome — nunca relançar às cegas

Nunca execute `google-chrome` diretamente e nunca repita um launcher porque o
terminal demorou. Use somente `~/tools/chrome-eng/launch.sh <eng> [url]`: ele
serializa chamadas com `flock`, detecta o processo raiz por perfil+porta antes
de abrir e desanexa stdin/stdout/stderr. Se já estiver aberto, deve retornar
`already running` em menos de 1 s sem criar target. Se um bootstrap falhar ou
estourar timeout, inspecione `~/.cache/chrome-eng-launch.log`, o PID raiz e a
porta CDP; NÃO tente de novo no mesmo tick. Motivo: cada invocação de
`google-chrome` contra um perfil já aberto vira nova aba/janela (`Opening in
existing browser session`). Validado 25/09: 5 chamadas concorrentes no Elastic
mantiveram o mesmo PID e zero targets novos; cold-start + segunda chamada no
Metro virtual também não duplicou.

## Self-trigger pós-tarefa (regra operador 13/09)
Quando um turno EXECUTOU uma ação e a fila `next_actions` ainda tem itens
open elegíveis (passive/verification/impact sem requires_operator), NÃO
espere o próximo tick do intervalo: no FIM do turno, dispare
`cronjob(action='run', job_id=<seu job id>)` — isso põe o job na fila do
próximo tick (~1min). O guard de dedupe do scheduler impede sobreposição.
Nunca self-trigger se: (a) nada foi executado no turno (noop — deixe o
auto-pause agir), (b) budget diário >= 80% consumido, (c) você pausou o
state. Isso implementa "terminou -> começa a próxima logo após" sem
paralelismo.

## Barreiras de codigo via Telegram (protocolo CODE)

Quando o pentest trava em algo que so o operador tem (OTP, link de email,
captcha, codigo de confirmacao), o ciclo e:

1. `python3 ~/tools/T3MP3ST/loop_barrier.py ask <eng> <timeout_s> '{"text":...,"why":...,"expires_at":...}'`
   → grava barrier, envia ao Telegram do operador o pedido com o id, e (sem
   `--nowait`) BLOCA ate o codigo chegar ou expirar. Ao expirar vira claim
   unverified (confiavel > rapido).
2. O operador responde no @Coronel69_bot: `CODE <id> <valor>`.
3. REGRA PARA O AGENTE DO GATEWAY (qualquer sessao que receber msg iniciada
   com `CODE `): procurar o `<id>` em `~/engagement-*/loop/state.json`
   (fila `barriers`, campo `delivery_path`), escrever `<valor>` EXATO naquele
   arquivo (chmod 600), rodar `python3 ~/tools/T3MP3ST/loop_state.py barrier <eng> done <id>`,
   responder "recebido" — e TENTAR CONSUMO IMEDIATO: se a pagina de login/OTP
   que criou a barreira ainda esta viva no browser dedicado do engagement
   (`:9222` Elastic / `:9223` Metronome-2; barreira de EMAIL/OTP → ler a caixa
   no Chrome Gmail dedicado `launch.sh gmail-idor` :9228 / `gmail-geral` :9229
   e extrair link/codigo via CDP — receta em `cdp-browser-session-driving`),
   abrir a aba, DIGITAR o codigo, 
   confirmar o post-login (ex.: /api/v1/user 200), rodar
   `barrier <eng> consume <id>` e retomar a acao travada. Se a sessao expirou,
   NAO consumir: o proximo tick do sweeper (passo 0) re-dispara barreira nova.
4. `loop_barrier.py check <eng> <id>` → PENDING ou VALUE:<valor>.

   PITFALL babysit/watchers longos (27/09, wolt): processos background
   lançados por sessão cron one-shot do harness morrem SILENCIOSAMENTE em
   <60s ao fim do turno (sem traceback, não é OOM). NUNCA confiar em
   `terminal(background=true)` p/ daemon que precisa sobreviver ao tick —
   criar systemd --user unit (`Restart=on-failure`, append no log,
   `systemctl --user start`) e verificar `is-active` + uptime >90s.

   PITFALL one-shots >7min (28/09, nebius): o terminal FOREGROUND tem timeout
   duro de ~420s e MATA o processo filho no expiry — `loop_decide.py decide`
   com MAS (25-40min) morreu 2x no STAGE 1 sem erro. Sintoma: log do painel
   congela em `── STAGE 1 ──` com 0 bytes depois. Soluções, em ordem:
   (1) `terminal(background=true)` + `process(action='wait')` em loop 180s
   (funciona em cron; o decide de 07:59 assim completou 40min);
   (2) p/ robustez máxima: `systemd-run --user --unit=<eng>-decide-<hhmm>
   --setenv=LOOP_MAS_TIMEOUT=2400 python3 ~/tools/T3MP3ST/loop_decide.py
   decide <eng>` e acompanhar `systemctl --user is-active` + mtime do
   mas-*.md. PITFALL (02/10, coindcx-decide-0221 exit 2): systemd-run NÃO
   expande `~` nem herda cwd — caminho RELATIVO do script morre com
   status=2/INVALIDARGUMENT sem traceback. Usar caminho ABSOLUTO do python
   E do script; checar `systemctl --user is-active` <1s após lançar. MAS timeout real (INCONCLUSIVO fail-closed) acontece por
   contenção NIM 40rpm quando elastic/stripe rodam painéis em paralelo —
   simples retry depois costuma passar; NUNCA LOOP_SKIP_MAS=1.
5. `loop_state.py barrier <eng> ready` → codigos entregues aguardando digite;
   `consume <id>` → le valor, marca consumed_at (nunca re-digita codigo velho).

### Abrindo as janelas certas quando várias barreiras aguardam o operador

Quando o operador pede para destravar vários engagements de uma vez, não basta listar as barriers — abra as janelas: para CADA barreira aberta, (1) `~/tools/chrome-eng/launch.sh <eng>` garante o Chrome dedicado vivo (nunca relançar às cegas — ver bootstrap singleton); (2) se esse Chrome roda em display virtual (Xvfb), re-homeie o MESMO perfil para o display visível do operador (receita passo a passo em `cdp-browser-automation`, seção "Moving a headless engagement Chrome onto the operator's visible display" — DISPLAY/XAUTHORITY explícitos, remover Singleton*, pgrep com bracket anti-self-match); (3) ative a aba exata da barreira via `Target.activateTarget` casando a URL COMPLETA (query string inclusa — substring dá falso-positivo) e levante a janela com `xdotool windowactivate` nesse display; (4) feche antes as abas mortas de erro/redirect (`tab_gc.py`). Entregue no fim um checklist por barreira: janela/aba aberta, a ação humana exata que falta (captcha, OTP, telefone+SMS), o id da barreira e a validade do `CODE <id> <valor>`. Se a página que criou a barreira já expirou, NÃO consuma o código — o próximo tick do sweeper re-dispara barreira fresca.

O valor NUNCA passa por LLM intermedio no caminho de volta — arquivo cru.
OTP e credencial: tratar como secreto, chmod 600, nao ecoar em log do loop.

## Toolbox de recon (skills irmãs — instaladas 23/10)
- `php2shell-scanner` — mass-scan do domínio-alvo p/ versões PHP na faixa
  dos CVEs php2shell (RCE 9.8). Em ação de RECON / enumerar superfície
  web de um domínio autorizado, rode o binário (caminho na skill) e
  registre hits VULNERAVEL como claim com `evidence` apontando pro
  results JSON. Detalhes na skill.
- `strix` — camada de ESCALADA com PoC (24/10): quando o recon apontar
  superficie promissora (endpoint, API, alvo web dentro do scope do
  engagement), rode `~/.hermes/scripts/strix-run.sh <target>` — deep-dive
  multi-agente budget-capped ($5 default, modo quick) com validação por
  exploit. Encaixa DEPOIS do recon e ANTES do gate MAS: findings do strix
  entram como claims com `evidence` = PoC do run. Só com keys vivas
  (checar daily_lock antes; se locked, deixar p/ próxima janela). LLM do
  strix vai via throttle proxy — zero risco pro orçamento 429. NUNCA
  submit: findings → MAS → draft (red-line).

## Invariantes duras
- MAS EM FUNIL (24/10, ordem do operador "faz ai" — substitui o MAS-SEMPRE
  13/09 na rotina; o gate submit-class 02/10 ABAIXO permanece INTACTO):
  todo decide com plano não-vazio entra no funil e PARA na primeira camada
  que resolver. Pular camada por conveniência não vale; decidir na camada
  certa é o desenho.
  1. PRÉ-FILTRO (grátis): o plano contém marcador de finding/risco
     (regex: CVE|vuln(erab|abilidade)?|exposed|bypass|RCE|IDOR|BOLA|SSRF|
     secret|token|admin|unauthorized|finding|claim|GO|submit|draft)?
     NÃO → transiente (recon/leitura/probe barato): executa SEM painel.
     SIM → camada 2.
  2. TRIAGEM IN-SESSION (grátis, mesmo turno): 7 perguntas do
     triage-validation + brocards do vulnerability-triage-brocards (skills
     irmãs). Candidato fraco morre AQUI e registra no state; não sobe.
  3. VERIFICADOR DETERMINÍSTICO (local, zero LLM): claim mecânica
     (binário, versão, endpoint, PoC reproduzível) → `mcp_reverify_*`
     (re_verify_claim) ou `mcp_ptai_*` (oráculos) ANTES de qualquer painel.
     VERIFIED/REFUTED com evidência decide sem LLM.
  4. CACHE DE VEREDITO (grátis): `python3 ~/tools/T3MP3ST/mas_verdict_cache.py
     check '<eng>|<classe>|<assinatura-estavel>'` — HIT com TTL vivo → aplica
     o veredito cached, SEM painel. Veredito novo (qualquer camada 5/6) →
     `set` com a mesma assinatura pra futuros replays.
  5. ESCADA LITE: sobrevivente → mas_lite com DIGEST ≤3K de input (nunca o
     raw da sessão), 3 agentes (pro/contra/árbitro), 2 rodadas máx; para
     validação rotineira o council IN-SESSION (skill irmã, 1 contexto, 4
     vozes) substitui o painel externo — LITE-PASS em classe de baixo risco
     fecha; LITE-FAIL, disputa, severidade alta ou anything reportável → sobe.
  6. PAINEL ADVERSARIAL PLENO (5 agentes, PRO vs CON até convergência):
     SEM EXCEÇÃO para submit-class/GO/draft — wiring 02/10 abaixo é o único
     caminho e não se substitui por camada nenhuma.
  Contenção preservada: tudo que PERSISTE (claim gravada, draft, submission)
  só existe validado (camadas 3/5/6 cobrem); o que morre em 1-2 é transiente.
  "Painel nunca pulado silenciosamente" segue valendo a partir da camada 5.
  Meta do funil: painel externo -80~90% de volume; loops voltam simultâneos.

### Gate adversarial no "report teoricamente pronto" (operador 02/10)
O painel single-pass do decide revisa CADA plano. Além dele, quando o planner
propõe uma ação **submit-class** (regex submit/submiss/msg-programa) apontando
um **draft de submission existente**, isso é o momento "report pronto" → roda
`mas_adversarial.py <draft>` (PRO vs CON até convergência) ANTES de a ação ir ao
operador. Wiring: `loop_decide.py` tem `adversarial_gate()` + `_resolve_draft()`
+ `DRAFT_RX`; anexa `a["adversarial"]={converged,submit_ok,verdict_line,report}`
à ação operator-gated. NUNCA auto-submete (red-line). `submit_ok=True` SÓ com
consenso estrito (ambos SUBMIT + mesma severidade); rendição unilateral
(CONCEDO de um lado) = RETIDO, não aprovação. Pula com `LOOP_SKIP_ADV=1` (só teste).

`mas_adversarial.py` roda **rodadas INDETERMINADAS** até um terminal:
CONSENSO (para), DIVERGENCIA-ESTAVEL (mesmo par decisão/sev repetido N vezes =
desacordo genuíno, não falta de rodadas), ou TRANSPORTE-INSTAVEL (fail-closed).
`run()` re-tenta automaticamente qualquer rodada com ERRO de transporte
(`_panel_errored`: rc≠0, saída vazia, árbitro mudo, ≥2 erros HTTP) — erro NÃO
conta como voto. Guard anti-loop: `hard_cap` ciclos produtivos (default 8) +
`attempt_cap`=3×hard_cap tentativas totais. Args/env: `mas_adversarial.py <draft>
[hard_cap]`, `MAS_ADV_STABLE` (default 2), `MAS_ADV_AGENTS`, `MAS_ADV_ARBITER`.

PITFALL frota NIM (02/10, custou 1 erro meu): TODOS os modelos NIM do painel
(glm-5.3, kimi-k3, gemma4, lightning, nemotron-super, deepseek-v4.1-flash)
entregam content SE `max_tokens` for ALTO o bastante — o `reasoning_content`
consome o budget primeiro. Um ping de teste com `max_tokens<=40` devolve
`content:null, finish_reason:length` e PARECE modelo morto: é falso-negativo.
NUNCA declarar um modelo do painel morto por ping de budget baixo; testar com
`max_tokens>=4000`. Painel/árbitro só caem de verdade por 429 (contenção 40rpm).
- Custo monetário do painel é ZERO (free tiers). Operador autoriza gastar modelo
  sem freio de quota (12/09: "pode botar pra fuder") — podar só por LATÊNCIA real
  (MAS 13min não vira ping por turno) e por quota free MORTA (glm-5.3-flash b.ai
  acabou 12/09; se um slug morrer, trocar debater p/ outro da frota, não desligar
  o painel). Veredito de MAS relevante para o operador pinga Telegram via
  `~/tools/T3MP3ST/mas_notify.sh '<topic>' '<vote>'` (wrap panel_mas + hermes send).
- kind=impact (registro/exploit/submit/qualquer write no alvo) JAMAIS executa
  sozinha — nem se o planner jurar que é seguro; o sweep nem enxerga esses items.
- Output de modelo ≠ finding: só `exhaust ok` + evidência em arquivo fecha claim.
- Painel nunca pulado silenciosamente (regra do gate).
- "Consenso do painel não é prova" — arbiter cego arbitra método, evidência arbitra fato.

## Bootstrap de um engagement novo

```bash
python3 ~/tools/T3MP3ST/loop_state.py init <eng>
python3 ~/tools/T3MP3ST/loop_state.py add <eng> explored '<[{surface,depth,evidence,verified}]>'
# sem state.json o sweeper ignora o engagement — o operador ativa por engajamento
```

## Comandos úteis

- `list` — visão geral (pendings, awaiting, paused)
- `sweep` — próxima ação passiva elegível (o que o cron executa)
- `exhaust` — checklist programático; único gate para dizer "terminei"
- `requeue-stale` — devolve in_progress órfãos (crash do sweeper)
- `block <id> <motivo>` — promove ação a awaiting_operator manualmente
