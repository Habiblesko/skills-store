#!/usr/bin/env python3
"""Live re-probe for dangling-DNS / cloud-takeover drafts (bug-bounty-report-writing).

Usage: python3 retest_dangling_dns.py host1 host2 ...   (or edit HOSTS below)

For each host: dig CNAME + A, resolve across 3 public resolvers (catches
split-horizon / stale caches), and if the CNAME points at a known cloud edge
(azurefd.net, azurewebsites.net, cloudfront.net, etc.) curl the canonical target
and capture the 404 BODY (removed-vs-not-found distinguishes 'endpoint present,
no route' from 'endpoint absent').

Why this exists: a takeover draft's premise can INVERT between first-observation
and submission day (Essity 2026-09-30: 6 hosts went NXDOMAIN -> resolving-with-
404-no-route). Run this on submission day, EVERY time, before trusting any
'FINAL' takeover draft. A contradicted premise BLOCKS the draft (re-classify +
re-run the confirmation panel); it does not get softened.
"""
import subprocess, json, sys, time

HOSTS = sys.argv[1:] or [
    # example set; replace with the draft's host list
    "id.smartcare.tena.com",
]
RESOLVERS = ["1.1.1.1", "8.8.8.8", "9.9.9.9"]
EDGE_MARKERS = ("azurefd.net", "azurewebsites.net", "azureedge.net",
                "cloudfront.net", "trafficmanager.net", "blob.core.windows.net")


def dig(host, rtype, resolver=None):
    cmd = ["dig", "+short", host, rtype]
    if resolver:
        cmd = ["dig", f"@{resolver}", "+short", host, rtype]
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=15).stdout.strip()
    except Exception as e:
        return f"ERR:{e}"


def curl_canonical(target):
    """Curl the CNAME target; return (http_code, body_head)."""
    try:
        code = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "--max-time", "12",
             f"https://{target}/"], capture_output=True, text=True, timeout=15).stdout.strip()
        body = subprocess.run(
            ["curl", "-s", "--max-time", "12", f"https://{target}/"],
            capture_output=True, text=True, timeout=15).stdout[:200]
        return code, body
    except Exception as e:
        return "ERR", str(e)


def main():
    out = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "hosts": {}}
    for h in HOSTS:
        cname = dig(h, "CNAME")
        a = dig(h, "A")
        resolvers = {r: (dig(h, "A", r) or "NXDOMAIN/empty") for r in RESOLVERS}
        rec = {"cname": cname, "a": a, "resolvers": resolvers}
        target = cname.rstrip(".") if cname and any(m in cname for m in EDGE_MARKERS) else None
        if target:
            code, body = curl_canonical(target)
            rec["canonical_target"] = target
            rec["canonical_http"] = code
            rec["canonical_body_head"] = body
            # classify
            if code == "404" and ("has been removed" in body or "Resource Not Found" in body):
                rec["class"] = "endpoint-present-no-route (AFD/edge live, unconfigured)"
            elif not a or "NXDOMAIN" in str(resolvers):
                rec["class"] = "nxdomain-dangling"
            else:
                rec["class"] = "resolves-check-manually"
        out["hosts"][h] = rec
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
