#!/usr/bin/env python3
"""Anti-AI-writing lint for bug-bounty submissions (bug-bounty-report-writing).

Usage: python3 ai_writing_lint.py <draft.md>

Flags the tells that actually surface in security drafts (basis: Wikipedia
'Signs of AI writing'). A triager who smells LLM slop discounts the whole
report. Run AFTER drafting, BEFORE the hostile gate. Zero findings is the
target for a paste-ready submission.

Exit 0 always (advisory); prints a findings list + stats. Not a hard gate —
read each flag and decide, because a few are legitimate in technical prose
(see FALSE-POSITIVE note below).
"""
import re, sys

CLICHES = [
    "delve", "tapestry", "multifaceted", "it's important to note",
    "it is important to note", "in conclusion", "in today's digital",
    "ever-evolving", "robust framework", "leveraging", "seamless",
    "comprehensive", "navigating the complexities", "a testament to",
    "plays a crucial role", "in the realm of", "underscores",
]
HEDGE_STACK = re.compile(r"\b(may|might|could|can)\s+(possibly|potentially|perhaps)\b", re.I)
UNICODE_TELLS = ["\u2192", "\u2713", "\u2022", "\u2014", "\u2018", "\u2019", "\u201c", "\u201d"]


def main():
    if len(sys.argv) < 2:
        print("usage: ai_writing_lint.py <draft.md>"); sys.exit(0)
    t = open(sys.argv[1], encoding="utf-8", errors="replace").read()
    findings = []

    em = t.count("\u2014")
    if em:
        findings.append(f"em-dash x{em} (target 0; rewrite as period/semicolon/parenthesis — strongest single tell)")

    for u in UNICODE_TELLS:
        if u == "\u2014":
            continue  # counted above
        n = t.count(u)
        if n:
            findings.append(f"unicode {u!r} x{n} (formatting-model fingerprint; use words or plain hyphens)")

    low = t.lower()
    for c in CLICHES:
        if c in low:
            findings.append(f"cliche: {c!r}")

    for m in HEDGE_STACK.finditer(t):
        findings.append(f"hedge-stack: {m.group(0)!r}")

    # rule-of-three puffery: three parallel 'cannot X, cannot Y, cannot Z' style
    for m in re.finditer(r"(cannot \w+[^.,;]*,\s*cannot \w+[^.,;]*,\s*cannot \w+)", t, re.I):
        findings.append(f"rule-of-three puffery: {m.group(0)[:60]!r}...")

    # trailing '-ing' clause chaining empty analysis (AI tell); NOT a gerund starting a bullet
    for m in re.finditer(r",\s+(highlighting|emphasizing|showcasing|underscoring|demonstrating|reflecting)\b", t, re.I):
        findings.append(f"superficial trailing participle: {m.group(1)!r} (chains empty analysis)")

    print("=== ANTI-AI LINT ===")
    if findings:
        for f in findings:
            print(f" - {f}")
    else:
        print("CLEAN — no tells detected")
    heads = len(re.findall(r"^#+ ", t, re.M))
    print(f"\nstats: {len(t)} chars, em-dash={em}, headings={heads}")
    print("FALSE-POSITIVE to ignore: a gerund STARTING a technical bullet "
          "('Replaying the value gives...') is fine; the tell is a TRAILING "
          "'-ing' clause that chains empty analysis.")


if __name__ == "__main__":
    main()
