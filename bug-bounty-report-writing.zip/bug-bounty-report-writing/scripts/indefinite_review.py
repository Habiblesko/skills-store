#!/usr/bin/env python3
"""
indefinite_review.py - adversarial review loop that iterates a bug-bounty
draft until CONVERGENCE, judged by an INDEPENDENT rotating second model.

Stop rule (caller enforces across rounds): zero-defect DOUBLE - two
consecutive rounds (DIFFERENT models) return no actionable defect. Any
correction resets the counter. No round cap when the operator says so.

Each invocation runs ONE round: a questioner model reads the draft + a
live-evidence summary and returns strict JSON. The CALLER (agent) triages
each defect against live evidence, applies valid fixes, re-verifies live,
resets the counter, and launches the next round with the NEXT model.

Usage:
  python3 indefinite_review.py <draft.md> <live_evidence.txt> --round N

Rotation suggestion (confirm each model is live first):
  round 0 -> opus-4-8 (Anthropic primary, no NIM needed)
  round 1 -> moonshotai/kimi-k3
  round 2 -> google/gemma-4-31b-it
  round 3 -> deepseek-ai/deepseek-v4.1-flash
  round 4 -> back to opus-4-8 ...

NOTES baked in from the 2026-10-01 CoinDCX session:
  - HTTP timeout = 600s: reasoning models burn budget on reasoning_content
    before first content byte; 180-240s is too short and returns ERROR.
  - The questioner system prompt MUST state the current real-world date,
    or cutoff-limited judges flag valid current-year dates as
    'future/hallucinated' and the loop never converges.
  - verdict:ERROR (read timeout) is neither clean nor a defect: re-run
    once with the larger timeout or swap in another live judge.

Env: set the NIM base/key for non-Anthropic judges; wire opus via the
house MAS helper. Adjust MODELS / endpoint to the local setup - this file
is a template for the loop STRUCTURE, not a hardcoded client.
"""
import json, sys, os, urllib.request, argparse, datetime

# Rotate the judge per round so no single model's bias decides convergence.
MODELS = [
    "opus-4-8",
    "moonshotai/kimi-k3",
    "google/gemma-4-31b-it",
    "deepseek-ai/deepseek-v4.1-flash",
]

NOW = datetime.date.today()
MONTH_YEAR = NOW.strftime("%B %Y")
YEAR = NOW.year

QUESTIONER_SYSTEM = f"""You are a hostile, senior HackerOne VDP triager doing a FINAL pre-submission audit of a bug bounty report. Find ANY reason the report is not yet 100% ready: factual errors, internal contradictions, stale/volatile values cited byte-exact, deploy-fragile PoC, count/label drift vs the artifact, unsupported claims, scope/eligibility gaps, AI-writing tells (em-dashes, unicode arrows, rule-of-three, hedge stacks), attribution/CWE/date inconsistency, anything usable to close N/A or 'cannot reproduce'.

IMPORTANT CONTEXT: the current real-world date is {MONTH_YEAR}. Dates in {YEAR} are CURRENT/PAST, NOT future and NOT hallucinated - do NOT flag {YEAR} dates as 'future dates' or 'AI hallucination' (that is a training-cutoff false positive). Only flag a date if it is internally inconsistent with OTHER dates in the same report.

Be adversarial and specific. Do NOT praise. Do NOT invent problems. Only report ACTIONABLE defects (a concrete change), not vague suggestions. If the draft is genuinely clean, say so with an empty defects list.

Return ONLY strict JSON:
{{"defects":[{{"sev":"high|med|low","where":"section","issue":"...","fix":"..."}}],"verdict":"DONE|NOT_DONE","clean":true|false}}
clean=true and verdict=DONE only when defects is empty."""


def build_user_prompt(draft, evidence):
    return (
        "LIVE EVIDENCE (re-verified today, authoritative - trust this over the draft's prose):\n"
        f"{evidence}\n\n--- DRAFT REPORT ---\n{draft}\n\n"
        "Audit the draft against the live evidence. Grep the draft's dated/behavioural "
        "claims against the evidence; any claim contradicting the evidence is a HIGH defect. "
        "Return the strict JSON only."
    )


def call_model(model, system, user, timeout=600):
    """Minimal OpenAI-compatible chat call. Adapt base_url/key to the local setup."""
    base = os.environ.get("REVIEW_BASE_URL", "https://integrate.api.nvidia.com/v1")
    key = os.environ.get("REVIEW_API_KEY", os.environ.get("HERMES_CUSTOM_INTEGRATE_API_NVIDIA_COM_API_KEY", ""))
    body = json.dumps({
        "model": model,
        "messages": [{"role": "system", "content": system},
                     {"role": "user", "content": user}],
        "temperature": 0.2,
        "max_tokens": 4000,
        "stream": False,
    }).encode()
    req = urllib.request.Request(base.rstrip("/") + "/chat/completions", data=body,
                                headers={"Authorization": f"Bearer {key}",
                                         "Content-Type": "application/json"})
    # 600s: reasoning models emit reasoning_content before first content byte.
    with urllib.request.urlopen(req, timeout=timeout) as r:
        d = json.load(r)
    return d["choices"][0]["message"]["content"]


def extract_json(text):
    """Last balanced {...} object with raw_decode - survives prose/banner noise."""
    dec = json.JSONDecoder()
    best = None
    for i, ch in enumerate(text):
        if ch == "{":
            try:
                obj, _ = dec.raw_decode(text[i:])
                if isinstance(obj, dict) and "verdict" in obj:
                    best = obj
            except Exception:
                pass
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("draft")
    ap.add_argument("evidence")
    ap.add_argument("--round", type=int, required=True)
    ap.add_argument("--timeout", type=int, default=600)
    args = ap.parse_args()

    model = MODELS[args.round % len(MODELS)]
    draft = open(args.draft, encoding="utf-8").read()
    evidence = open(args.evidence, encoding="utf-8").read()
    user = build_user_prompt(draft, evidence)

    try:
        raw = call_model(model, QUESTIONER_SYSTEM, user, timeout=args.timeout)
    except Exception as e:
        print(json.dumps({"round": args.round, "model": model,
                          "error": str(e), "verdict": "ERROR", "clean": False}))
        return

    obj = extract_json(raw)
    if not obj:
        print(json.dumps({"round": args.round, "model": model,
                          "error": "no-json", "raw": raw[:500],
                          "verdict": "ERROR", "clean": False}))
        return
    obj["round"] = args.round
    obj["model"] = model
    obj.setdefault("clean", not obj.get("defects"))
    print(json.dumps(obj))


if __name__ == "__main__":
    main()
