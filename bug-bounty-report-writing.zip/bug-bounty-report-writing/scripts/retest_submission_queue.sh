#!/usr/bin/env bash
# Queue-wide submission re-verify sweep (bug-bounty-report-writing).
# Enumerates EVERY submission draft across all engagements and prints a
# per-draft checklist so no "FINAL/v4/ready" draft gets pasted unchecked.
#
# Lesson (2026-09-30): of 11 drafts marked ready across 8 engagements, a
# same-day live re-verify found only 3 still reproduced. 2 were factually
# FALSE (premise inverted since drafting), 3 were blocked by dead sessions,
# 2 were already internally N/A'd. A draft's confident filename is the
# WEAKEST evidence it is submittable. Never trust the queue; re-test it.
#
# Usage: bash retest_submission_queue.sh [engagement-glob]
#   default glob: ~/engagement-*
set -uo pipefail
GLOB="${1:-$HOME/engagement-*}"

echo "# Submission queue re-verify inventory ($(date '+%Y-%m-%d %H:%M'))"
echo
n=0
for d in $GLOB; do
  [ -d "$d/reports" ] || continue
  eng=$(basename "$d")
  # canonical draft per finding = newest of each family (strip -v2/-v3/-FINAL)
  for f in "$d"/reports/submission*.md; do
    [ -e "$f" ] || continue
    n=$((n+1))
    title=$(grep -m1 -E '^#|Title' "$f" | sed 's/^#* *//' | cut -c1-90)
    sev=$(grep -m1 -iE 'severity' "$f" | sed 's/^[^A-Za-z]*//' | cut -c1-60)
    # extract live hosts/endpoints the draft names (http[s] URLs + bare hosts)
    hosts=$(grep -oE 'https?://[a-zA-Z0-9.-]+' "$f" | sort -u | head -4 | tr '\n' ' ')
    echo "## [$n] $eng :: $(basename "$f")"
    echo "- title: ${title:-?}"
    echo "- sev:   ${sev:-?}"
    echo "- hosts: ${hosts:-none-found}"
    echo "- CHECKLIST (do ALL before calling submittable):"
    echo "  [ ] live replay of the PoC EXACTLY as written (copy from code block, not memory)"
    echo "  [ ] premise still true? (dig/curl every host TODAY; re-verify can INVERT the class)"
    echo "  [ ] session/trial alive? if PoC needs auth and session is dead => SUBMIT-BLOCKER"
    echo "  [ ] every host in scope file? grep -i <host> \$eng/scope/*"
    echo "  [ ] anti-AI lint: scripts/ai_writing_lint.py"
    echo "  [ ] adversarial panel (padrao_confirmacao.py) or hostile self-taxonomy"
    echo
  done
done
echo "total drafts: $n"
echo
echo "# Classify each into: SUBMIT (repro today) / REWRITE (premise stale) /"
echo "# BLOCKED (dead session) / CUT (already N/A). Save the matrix to a file;"
echo "# a per-draft verdict+reason beats a flat list (operator wants the reason)."
