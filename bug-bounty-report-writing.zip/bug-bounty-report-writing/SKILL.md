---
name: bug-bounty-report-writing
description: Use when writing bug bounty or pentest report submissions.
version: 1.2.0
author: c0lonello, Hermes Agent
license: MIT
---

# Bug Bounty / Pentest Report Writing

Skill for writing **submissions that get accepted and paid** on HackerOne, Bugcrowd, Intigriti, and other platforms. Based on analysis of real disclosed reports (Zomato CORS $550, Starbucks Subdomain Takeover CVSS 8.4, Publitas CORS) and the HackerOne Quality Reports guide.

## Before you write: confirm → force → impact

Treat findings as **hypotheses**, not conclusions. Do not stop at N/A or "is vulnerable." Run the loop:

1. **CONFIRMAR** — re-verify the finding live. Capture the raw HTTP request/response headers that prove the misconfiguration exists.
2. **FORÇAR** — force the exploit path to a concrete artifact: session cookie value, PII record, data exfiltrated. If the finding is CORS + non-HttpOnly cookie, craft the fetch PoC and capture what it returns. If it's a takeover, confirm the CNAME + deleted-resource fingerprint.
3. **IMPACTAR** — use the artifact to prove what an attacker can actually do: read user data, hijack a session, serve phishing, exfiltrate PII. The impact must be demonstrated, not just stated.

Only after the loop is complete does the report body get written.

**Sequence rule (operator, 2026-09-28):** the governing skill is loaded
BEFORE the first draft line, not after — loading
`security/bug-bounty-report-writing` at redaction time caught a
severity-inflated claim ("hardcoded secret = Medium" downgraded to honest
Low/Medium because the unlocked routes returned only public data, no PII)
before it burned the finding. Never write a submission from memory of how
reports look.

## The accepted-report formula

Every report must have these six sections, in order:

### 1. Title

`[affected_asset] Vulnerability Type — specific attacker outcome`

Weak: `CORS vulnerability`
Strong: `[b2coccapi.app.essity.com] CORS Misconfiguration allows cross-origin read of authenticated customer PII`

### 2. Summary (2-3 sentences)

What is the bug and why does it matter. Assume the triager has never seen the application.

### 3. Description + Steps to Reproduce

Numbered steps starting from a clean state. Include:
- Full HTTP **request** (headers: Origin, Cookie, Host, User-Agent, X-HackerOne-Research if applicable)
- Full HTTP **response** (headers showing Access-Control-Allow-Origin, Set-Cookie, etc.)
- For CORS: test multiple origins (evil.com, null, attacker.example.org) and show the matrix
- For takeover: `dig +short CNAME` output + `curl` fingerprint
- Control tests: show the sibling service that does it right (proves misconfiguration is unintentional)

### 4. Proof of Concept (PoC)

A functional code snippet the triager can copy and run:
- CORS: full HTML page with fetch/XHR + credentials:include + the exfiltration function
- Takeover: the exact registration chain (or the fingerprint evidence if resource not claimed)
- Auth bypass: the exact HTTP request that bypasses the control

### 5. Impact

Concrete, demonstrated attacker outcome:
- What data can be read? (profile, orders, PII fields — list them)
- What actions can be performed? (account takeover, modification, phishing)
- Who is affected? (customer base, geo, sensitive context like health products)

If the impact is stated but not shown, the report gets marked Informative.

### 6. Remediation (optional but appreciated)

2-3 bullet points of actionable fixes specific to the platform/service.

## Four rejection reasons and how to prevent them

| Reason | Fix |
|--------|-----|
| **Cannot reproduce** | Test your own steps on a fresh browser session before submitting. Include full HTTP requests from Burp. Note prerequisites explicitly. |
| **No demonstrated impact** | Always answer "What can an attacker actually do?" Show the data that gets exposed. Use the confirm→force→impact loop. |
| **Duplicate** | Search the program's disclosed reports and duplicates before filing. File one report per root cause, not one per endpoint. |
| **Out of scope** | Verify scope before testing. Document the scope reference in the report. |

## How to study real accepted reports

HackerOne discloses accepted reports. Use this to study program expectations:

```bash
# Metadata (severity, bounty, state):
curl -s https://hackerone.com/reports/<ID>.json

# Full report body (from GitHub mirror of disclosed reports):
# https://raw.githubusercontent.com/ajaysenr/HackerOne-Disclosed-Reports/main/reports/<ID>.md
```

Key reports to study (see `references/hackerone-report-examples.md`):
- Zomato CORS (#426165) — $550, 243 votes. Perfect example of CORS submission with hosted PoC.
- Starbucks Subdomain Takeover (#661751) — High CVSS 8.4, 122 votes. Takeover CNAME + Azure resource creation.
- Publitas CORS (#2332728) — Resolved. Simple CORS with HTML PoC.

For a wide-sample picture of what gets accepted and paid, see
`references/writeup-corpus-analysis.md` — stats from 14,877 disclosed reports
(top vuln types, top bounties, which programs disclose most, the 7-Question
Gate validation, and report-writing lessons from pentest-agents mistakes.md).

## MANDATORY MULTI-PASS REVIEW GATE (run on EVERY submit, no exceptions)

Operator directive (2026-10-01, "adicione como tecnica obrigatoria ao criar
um submit"): a draft is NOT ready after one review pass. Every submission
runs the fixed sequence below before it is called ready. Never single-pass,
never skip a layer, never trust a confident filename (`-FINAL`, `-v3`) as
evidence of readiness. Each pass has a DISTINCT focus so a second look does
not just repeat the first. The individual checks already live in the
sections below; this gate is the ORDER and the obligation to run all of them.

- **Pass 1 - Eligibility & policy (biggest N/A source).** Pull the program's
  LIVE policy and HackerOne's Core Ineligible Findings list
  (`docs.hackerone.com/.../8494488` via the logged-in `:9222` browser
  `.innerText`, NOT web_extract which is search-only; fallback when the CDP browser is offline: Jina Reader renders both pages, `curl -s https://r.jina.ai/https://hackerone.com/<program>` and the same prefix on the docs.hackerone.com ineligible URL, proven live 2026-10-17; save the capture to `evidence/` with the date). Confirm the finding
  CLASS is not on the ineligible list, confirm scope posture (open-scope vs
  listed), and quote the program's OWN rule for the class verbatim when it
  recognises one (see hostile-gate item 10). In-scope != eligible class.
  **Read the TARGET ASSET'S OWN status column in the scope table, not just
  whether the host/product appears** (Elastic datasource, 2026-10-19). The
  scope table carries per-asset `Coverage` and `Bounty` columns; an asset can
  be LISTED by name yet marked `Out of scope` / `Ineligible`. The ES|QL
  datasource wildcard-authz finding was proven against
  `docker.elastic.co/.../elasticsearch:9.5.3` = exactly the H1 asset named
  **"Elasticsearch"** (Type Executable; "All platforms", "Docker container",
  "Source code: github.com/elastic/elasticsearch", "Instance on Cloud") which
  the scope table marks `Out of scope / None / Ineligible` (updated
  2026-09-21). There is NO correct in-scope asset for that finding: the
  `*.elasticsearch.com` wildcard is marketing DNS, not the engine, so
  selecting it would misrepresent scope, and "no asset" gets triaged as
  out-of-scope. When the only asset that actually contains the bug is
  Ineligible, the finding is NOT submittable on that program right now - say
  so and stop; do NOT pick an adjacent wildcard to force a submission. Grep
  the asset row verbatim from the scope-table `.innerText` (search by product
  name, then read the trailing `In scope`/`Out of scope` + `Eligible`/
  `Ineligible` tokens on that asset's block) BEFORE investing in the report.
  The companion check: for a two-report engagement, the asset that is in-scope
  (here `cloud.elastic.co` for the Cloud-API oracle report) tells you which
  draft to prioritise; verify each report's asset status independently.
- **Pass 2 - Duplicate check.** Search the program's disclosed hacktivity
  (logged-in browser) for the asset's distinctive terms (secret name, host,
  header, finding phrase). Record "no public duplicate; cannot see private"
  honestly in testing notes. One report per root cause.
- **Pass 3 - Live re-verify, same-day, with negative control.** Re-run the
  core PoC NOW. Status codes / hashes / exact-match gate values stay
  byte-exact; quantities from LIVE data (payload sizes) get approximated
  (`~63 KB`) with one line that the value drifts and the STABLE part is the
  behaviour (the 200-vs-403 split). A re-verify can INVERT the finding class
  (hostile-gate item 1) - if it contradicts the premise, BLOCK and
  re-classify. If the PoC needs an auth session that is now dead, that is a
  SUBMIT-BLOCKER, not a pass.
- **Pass 4 - Hostile self-review taxonomy.** Read your own draft as a triager
  trying to close it (full list under "Self-review defect taxonomy"). Hit the
  recurring killers: factual self-contradiction, deploy-fragile PoC (derive
  volatile bundle hashes at runtime), count drift, shell-escape corruption,
  ambiguous labels, over-precise volatile numbers, leaked internal meta. When
  severity hinges on what a header/param IS, prove it from the shipped client
  SOURCE and quote it (the `Ys(aa,"X-Allow-Id",xe.BFF_SECRET)` usage-grep that
  killed "works-as-designed" on CoinDCX), not from response codes.
- **Pass 5 - Anti-AI lint + mechanical consistency.** Run the linter
  (`scripts/ai_writing_lint.py` or the engagement's `ai_lint`): ZERO
  em-dashes, zero Unicode arrows/bullets in prose, no rule-of-three puffery,
  no hedge stacks. Then the consistency sweep (hostile-gate item 6):
  attribution handle == operator's CURRENT handle (`c0lonnello`, 2 N),
  CWE IDs, dates, the secret/hash identical in every occurrence, title
  <=100 chars, no leftover `v2/v3/decide-later` editorial notes.
- **Close - Adversarial confirmation.** Run the PRO-CON panel
  (`mas_adversarial.py` / `padrao_confirmacao.py`) with the strict
  convergence rule (both sides agree = CONFIRMED; CON unilateral CONCEDO
  without an explicit SUBMIT = DIVERGE = retained, goes to operator). The
  verdict and severity come from this panel, never from the drafting model's
  self-assessment. If the external panel is unavailable, do Pass 4 yourself
  as the hostile reader AND say in the handoff that the panel did not run.

Submit itself (the H1 click / OTP) is an operator red-line regardless of
how many passes cleared. The gate decides SUBMITTABLE; the operator decides
SUBMIT. Worked example that produced this gate: CoinDCX BFF hardcoded-secret
v3 - P1 proved in-scope + not-ineligible, P2 found zero public dup, P3 kept
byte-sizes approximate (they drifted every retest), P4 added the source-level
X-Allow-Id proof, P5 landed lint-clean.

### Indefinite adversarial review loop (operator directive, 2026-10-01)

When the operator wants "revisoes indefinidamente ate 100% sem erros com
outra IA questionando se realmente acabou", the fixed 5-pass gate is not
enough - iterate until CONVERGENCE, judged by an INDEPENDENT second model,
not by the drafting model's self-assessment. Runnable harness:
`scripts/indefinite_review.py <draft.md> <live_evidence.txt> --round N`.

Design that works (settled with the operator this session):
- **Rotate the questioner model each round** so no single model's blind
  spots or bias decides convergence. A confirmed-live NIM roster plus the
  current Anthropic primary rotated well: opus-4-8 -> kimi-k3 -> gemma4 ->
  deepseek-v4.1-flash -> repeat. The Opus/primary rounds need no NIM and
  run while a slow NIM round is still in background.
- **Stop rule = zero-defect DOUBLE**: two CONSECUTIVE rounds (different
  models) returning no actionable defect. One clean round is not enough.
  Any correction resets the counter to zero.
- **No round cap** when the operator says "custe o que custar", but give a
  checkpoint summary every ~10 rounds so they keep visibility.
- Each round: the questioner returns strict JSON
  `{defects:[{sev,where,issue,fix}], verdict:DONE|NOT_DONE, clean:bool}`.
  TRIAGE every defect against live evidence before applying - the questioner
  is sometimes wrong (see model-cutoff false positive below). Apply valid
  fixes, re-verify live, reset the counter, next model.

Two failure modes this loop specifically defeats, both PROVEN this session
(the CoinDCX BFF draft had already passed 5+ of my own earlier review
rounds and still carried these):
- **Factual self-contradiction vs the evidence file.** The draft asserted
  "on 2026-09-28 the production value returned 200 against the staging host"
  while the engagement's own cross-host evidence showed
  `norge-bff.oktostage.com -> 403/403`. The report claimed the OPPOSITE of
  its own raw file. A rotating adversary (kimi) caught it; my repeated
  self-reviews never did. Lesson: grep the draft's dated behavioural claims
  against the raw evidence JSON, don't trust the prose.
- **Label/count drift vs the artifact.** The draft said the secret appeared
  "twice in staging configs, once in production"; the live bundle actually
  ships three NAMED config blocks (`environmenDev`, `environmentStage`,
  `environmentProd`), two pointing at the staging host and one at prod.
  "Two staging" was wrong; re-grep the artifact for the real block names
  and propagate the corrected wording to EVERY occurrence (summary, repro
  comment, staging note, impact).

**Model-cutoff false positive (must filter or the loop never converges).**
A questioner model whose training cutoff predates the real date will flag
valid current dates (2026-...) as "future dates / AI hallucination / fake
report". gemma4 did exactly this. This is NOT a defect - discard it. Bake
the correction into the questioner system prompt ("the current real-world
date is <month year>; dates in <year> are current/past, not hallucinated;
only flag a date if internally inconsistent with OTHER dates"), otherwise
every cutoff-limited judge blocks convergence forever on a non-issue.

**Reasoning-model timeout inside the harness.** deepseek-v4.1-flash can
exceed a 180-240s urllib timeout (reasoning_content burns the budget before
first content). Set the harness HTTP timeout to 600s, run the round in
background with notify, and do NOT kill a judge that is still alive (`ps`
confirms the PID) - same roster lesson as the panel. If a judge returns
`verdict:ERROR` (read timeout), it is neither clean nor a defect: re-run it
once with the larger timeout, or swap in another live judge for that turn
so one degraded model cannot stall the loop.

## Processing an external fact-check of your draft (2026-10-17)

The operator regularly routes drafts through an external AI (GPT-6/ChatGPT, Opus, Codex) and pastes the critique back. That critique is INPUT to verify, not an authority to obey: the reviewer has NO access to your evidence files, so its tables mix procedente corrections with items your own disk already answers, and it will mark on-disk-verified facts as "not independently confirmed". Workflow that closed the Elastic ds1 fact-check in one pass:

1. **Triage every row against disk before editing.** Three buckets: (a) PROCEDENTE — critique right, draft wrong: fix it (ds1: the `z` settings-example was IN-scope under `["?"]`, proving response shape not boundary; CVSS 4.3 is Medium per FIRST v3.1, Low ends at 3.9). (b) REFUTABLE-WITH-EVIDENCE — the reviewer lacked the file; answer from disk (live policy capture, dup-check pagination artifacts, source-read code lines) and CITE the artifact in the report so the triager has it too. (c) GENUINELY UNVERIFIED — say so in the report ("annotation only, no live-Serverless claim").
2. **Grep official docs before ANY impossibility/absolute claim.** The old ds1 text said credentials "never get stored in the clear to begin with"; the Elastic security page documents `cluster.state.encryption.required: false` = unencrypted storage with only a log warning. What actually prevents leakage is response masking (`::es_redacted::`, "Credentials are never returned in API responses"). Encryption-at-rest and response masking are DIFFERENT mechanisms; confusing them is a reviewer-grade factual error. Both belong in the report, correctly separated.
3. **A material rewrite invalidates earlier validation.** Re-run lints AND the adversarial gate on the CURRENT text — a pre-critique verdict belonged to the old draft. (ds1 post-rewrite re-run: 3 cycles, PRO=SUBMIT-medium 3/3, CON=CONCEDO-bypass-confirmed 3/3, blind arbiter confirms Medium; label DIVERGENCIA-ESTAVEL, content = technical approval without formal consensus — report it exactly that way, per the standing CONCEDO rule.)
4. **Read the panel's ACTUAL composition from the transcripts before describing the validation** (ds1 round-2 catch, 2026-10-18): all six transcripts said `posições válidas: 1/2` — one judge slot UNAVAILABLE in every cycle — so the run was a DEGRADED panel, and the closure summary calling it full adversarial validation was itself an overclaim a second reviewer killed. Grep `posições válidas: N/M` in every transcript; also read the arbiter's RAW turns: a first-turn `NAO-na` with real reasoning, discarded on a FORMAT re-ask, then a Medium verdict, is an oscillation to record (both turns) — not a template echo to wave away. Published verdict != the path.
5. **Second-round reviewers attack your CLOSURE SUMMARY, not just the draft.** Round-2 on ds1: (a) "trial license" was a presumption — the docker default is `basic`, `GET /_license` was never captured; never presume environment state, add the capture to the PoC script; (b) file identity across release tags is NOT runtime behavior — label version-range claims as inference when you ran only one version ("byte-identical file, therefore same behavior follows as a strong inference, not a runtime observation"); (c) "rules out duplicates" overclaims a 23-term/600-char-summary search — write "no duplicate was identified by a reasonable-term search of the disclosed set"; (d) a combination not captured in a single request (settings populated + out-of-scope entry, in one response) is an inference, never an observed fact — keep observation / inference / pending explicitly separated in the report text.
6. **The readiness criterion is evidence-shaped, not ceremony-shaped** (round-3 ruling, 2026-10-18): a re-run MAS panel or a fresh dup-check are COMPLEMENTS, never certificates — repeating a debate until it reaches favorable consensus is bias, not validation, and neither certifies the finding nor guarantees absence of duplicates. READY means exactly: (i) every claim in the draft is compatible with the captured evidence, (ii) the environment is documented (build, license, flags — captured, not presumed), (iii) limitations are explicit in the text. No acceptance prediction, ever.
7. **PoC-script hygiene for anything you might share or attach** (round-3): zero literal passwords in the script body — parse credentials from a 0600 file; no truncated captures (`head -c N` removed — full bodies via `python3 -m json.tool`); end with a global PASS/FAIL validation over explicit criteria (body captured, boundary payload present, license captured, build captured) whose exit code reflects the result — never an unconditional `done`. Markers like `CONFIRMED` printed by the script are the script's own conclusion, not independent evidence; examine the output critically. The FAIL direction is just as treacherous as a false PASS: a script's automated FAIL can be a SETUP bug, not a true negative of the finding. Worked case (ds1 2026-10-18): the complementary PoC reported `settings_outofscope_vazaram=FAIL` only because its setup `PUT` used an invalid setting (`bucket` is not a known ES 9.5.3 datasource setting -> HTTP 400), so the out-of-scope datasource was never created and the leak test had no subject. The finding was real; the script failed at setup. Rule: on any PASS/FAIL from your own harness, READ the response bodies it captured and separate three states - (a) setup errored (4xx on a precondition PUT) = invalid test, fix and re-run; (b) ran and did not reproduce = true negative; (c) ran and reproduced = positive. A blind `CONFIRMED`/PASS hides (a) exactly as much as a blind FAIL does.

Full worked example (all three review rounds, item-by-item verdict tables, artifact paths): `references/external-factcheck-processing.md`.

## Pre-submission hostile gate (run AFTER drafting, BEFORE copy-paste)

A draft that passed the confirm→force→impact loop can still be N/A-bound on presentation and stale premises. Re-verify each of these on the SAME DAY as submission — evidence ages (services get redeployed, fingerprint lists change):

1. **Re-verify every live fact today.** dig/curl all hosts again; a "Related" table from 2 weeks ago can be 100% stale (Azure Web Apps that 404'd then came back alive behind auth). Include only rows verified today; state both dates ("first observed 09-01, re-verified 09-14 — persistence itself rules out transient errors"). **Re-verify can INVERT the finding class, not just refresh it** — a draft filename saying FINAL/v4/ready is the MOST dangerous kind because its confidence invites paste-without-checking (Essity 2026-09-30: `submission-takeover-FINAL-v4` claimed "NXDOMAIN, AFD deleted"; the same 6 hosts now RESOLVE to live AFD endpoints returning 404-resource-removed = a DIFFERENT finding class, making the draft's core sentences factually false). When re-verify contradicts the premise, BLOCK the draft and re-classify from scratch — record the delta as a proven claim in the engagement state with raw dig+curl evidence, do NOT soften the old draft to "mostly fit." Run `references/../scripts/retest_dangling_dns.py <hosts>` on submission day for any DNS/takeover draft. **If re-verify itself is impossible because the session/trial died, that is a SUBMIT-BLOCKER, not a pass.** A dead trial session shows only analytics cookies surviving (e.g. `ebtSessionId` present but `ec_session` gone → the auth-gated oracle returns 401 `root.unauthenticated` on both the member and non-member probe, so the oracle can't be demonstrated). Elastic Cloud trials expire ~14 days after signup; the auth cookie rotates in ~1h. You cannot answer a triager's re-PoC request on a dead session — the report closes "unable to reproduce." Restore a live session (vault load, or new trial via the OTP/captcha operator barrier) BEFORE submitting anything whose PoC needs auth.
2. **CVSS: compute, never hand-map.** `pip install cvss` then `CVSS3('CVSS:3.1/AV:...').scores()[0]`. Drafts routinely carry vectors that don't equal the quoted score (a real draft: vector worth 7.4 labeled 6.1; also avoid C/I/A:H without demonstrated read/modification — A:N unless DoS is implied; UI:R when impact needs a victim to visit). Sanity-check the calculator against known values (classic reflected XSS S:C C:L I:L = 6.1).
3. **Authenticated-impact claims need the auth mechanism proven.** Before promising "reads PII", check `WWW-Authenticate` and the real login flow: SAP Commerce/Hybris OCC reflects CORS on a 401 `WWW-Authenticate: Bearer` while the SPA gets its token from `/authorizationserver/oauth2` (memory/localStorage, JSESSIONID scoped to the auth path only) — cross-site `withCredentials` replays NOTHING. Header reflection without a proven cookie session = theoretical = N/A on impact-based programs. Corollary: test the preflight with your research header — custom headers get 403, so a PoC page that adds `X-HackerOne-Research` silently breaks.
4. **Takeover classes expire.** can-i-take-over-xyz is a snapshot, not law: `azurefd.net` is no longer listed Vulnerable, and Microsoft's AFD defaults endpoint-name reuse to `TenantReuse` (deleted name re-provisionable by the same Entra tenant; custom-domain attach requires `afdverify.*` validation) — a dangling CNAME to a hashed `.a01.azurefd.net` endpoint may be dangling-DNS hygiene (Low/Informative), not takeover. Grep the CURRENT upstream list + vendor docs before writing "standard accepted evidence basis". See `references/takeover-and-cors-evidence-pitfalls.md`.
5. **Never disclose internal LLM-panel opinions.** "cross-validation panel rated UNCERTAIN 0.65" reads as self-doubt and invites N/A; fix or drop the claim instead. Scope claims need the program's own words — capture the policy page verbatim (logged-in browser `.innerText` of the program page; a fresh /json/new CDP tab may return empty body — navigate + wait, or reuse an existing tab), and drop hosts outside listed roots (a non-owned domain in the table can contaminate the whole report).

   **Cross-check EVERY host named in the report against the local scope file, not memory.** A real audit caught a draft asserting `api.elastic-cloud.com` "(Domain, in scope)" when the engagement's own `scope/scope.csv` (74 lines) listed ONLY `cloud.elastic.co` — the API host wasn't there at all. `grep -i '<host>' scope/scope.csv` for each host before paste; a single unlisted host that the triager checks derails credibility for the whole report. For **Open-Scope** programs (rewards for any owned asset by impact), an off-list host is still coverable BUT you must PROVE ownership from the primary app itself: e.g. 1win's own home page shipped `window.INITIAL_DATA = {... "afh":{"routerDomain":"flowmetric.life"} ...}`, declaring the off-list tracking host as its own infra — that config quote is the ownership evidence, and it belongs in the report to preempt the "is this yours?" objection.
6. **Mechanical consistency pass.** Report title ≤100 chars (H1 limit); the header/attribution handle in evidence must equal the handle named in the report text; every command shown must match what was actually run (curl -sk vs curl -s, header present or noted as abbreviated); WSTG IDs correct (subdomain takeover = WSTG-CONF-10); no leftover editorial "v2/v3/decide later" notes in the paste-ready copy.

7. **Kill absolute-quantifier claims that a live test can refute.** Words like "unlimited", "no rate limiting observed", "no protection", "internal error code leak" are the exact bait a triager will re-test in 30 seconds. A real audit caught "unlimited" in a draft when a 20-POST loop showed 17/20 pass (Cloudflare code 1015 blocked 3) — the endpoint was permissive, not unlimited; the truthful phrasing ("85% pass under residual rate limit, only slows not stops") is stronger AND survives verification. Similarly, error codes labeled "internal" often turn out to be the service's own public error format (`PT-E1` on a public tracker was the standard client-facing code, not a leak). Run the live test THEN write the number; never write the adjective THEN forget to test.

8. **Audit re-verify: run the volume/negative-control probes YOUR draft implies.** Before submission, re-run every measurable claim in the draft against the live endpoint (POST accepts anon? volume test. rate limit? loop. adjacent route? enumerate /api/v1/*). Two upgrades commonly emerge: (a) an unclaimed adjacent finding worth naming as "attack surface" (e.g. `GET /api/v1/visits → 401` alongside the anon POST endpoint — concrete pointer beats "more endpoints may exist"), and (b) numbers to replace hand-waves. A 20-minute probe pass routinely converts 2–3 vague sentences into defensible data.

9. **Evidence-artifact audit: every concrete claim must map to a raw file on disk.** Before calling a submission "100% ready", grep the draft's specifics (probed IDs, sweep ranges, counts, dates) against `evidence/` — a draft citing "7 adjacent user IDs probed, all 400" with NO raw artifact containing those IDs cannot answer a triager's "where's the capture?". If the raw file is missing and a live session exists, RE-RUN the probe now and save it (2026-09-26: Elastic membership-oracle draft cited a 7-UID adjacent sweep with no raw file → re-ran with the live session, `evidence/oracle-adjacent-uid-sweep-2026-09-26.json` = 7×400 uniform + 403 positive control in the same session; the draft claim now stands on disk). If the session is dead and the claim can't be re-verified, CUT the claim from the draft — an uncited claim is worse than a shorter report.

10. **Match the finding class against the platform's canonical ineligible
   list, not just the program scope** (2026-10-01). "In scope" and "eligible
   finding class" are different gates; a finding can be on a listed asset yet
   closed as a Core Ineligible Finding. Before investing, pull HackerOne's
   live list (`docs.hackerone.com/.../8494488-core-ineligible-findings` —
   JS-rendered, fetch via the logged-in `:9222` browser `.innerText`, not
   web_extract which is search-only) and check your class against every item.
   For the CoinDCX BFF hardcoded-secret finding the only near-matches were
   "theoretical / no real-world impact" (defeated by a demonstrated 403→200
   bypass) and "most issues related to rate limiting" (defeated by the
   source-level proof that X-Allow-Id is a static shared value). Also quote
   the program's OWN rule for the finding class when it recognises it — CoinDCX
   policy says *"For exposed credentials or secrets, limit yourself to
   verifying the credentials' validity"*, so citing it verbatim both proves
   the class is accepted AND shows the testing stayed within the stated
   limit, preempting "you tested too much". The live policy page also carries
   the authoritative scope posture (CoinDCX = Open Scope, "accepts reports
   for all owned assets based on impact, even if not listed") — capture it to
   back an off-list but owned host.

Run this as an adversarial reader: have an external model role-play a VDP triager against the draft + raw evidence file and answer only "unsupported facts / placeholders / killable claims / PRONTO or NAO-PRONTO" — one such gate killed a High-takeover draft two rounds before submission (see #4). When the gate verdict is NAO-PRONTO, file a GATE-*.md with the reasons; do not soften and resubmit around it.

## Submission-queue discipline ("o que temos submetível?")

The operator asks for the submittable queue repeatedly; every answer is a
per-draft verdict with a REASON, never a flat list (proven 2026-09-28).
For a queue-wide re-verify pass, run `scripts/retest_submission_queue.sh`
(see "Queue-wide re-verify sweep" below).

- **SUBMIT** items: one-line why (e.g. "PoC runtime + self-sufficient impact";
  "unauth + concrete artifact + money angle") + file path.
- **HOLD** items: the exact executable gap that upgrades them ("SUBMIT if X
  unlocks Y") — becomes a next_action in the engagement state, not a dead end.
- **Gated** items: the missing operator gesture (account, GO, claim, OTP).
- Verdicts come from the adversarial pass (v3 critic / PRO-CON panel), never
  from the drafting model's self-assessment — the CoinDCX draft was written
  Medium and honestly landed Low only after dual external review.

### Queue-wide re-verify sweep ("do this for ALL submissions", 2026-09-30)

When the operator says "do it for all submissions" / "what's submittable",
do NOT answer from the drafts' filenames or your memory of them. Enumerate
the whole queue and live-re-verify each ONE, then classify. The hard number
from the first full sweep: of 11 drafts marked ready across 8 engagements,
only 3 still reproduced same-day. A confident filename (`-FINAL-v4`) is the
WEAKEST evidence a draft is submittable, not the strongest.

Run `scripts/retest_submission_queue.sh` to enumerate every draft with a
per-draft checklist, then bucket each into exactly one of:
- **SUBMIT** — PoC reproduced live today; only the adversarial panel remains.
- **REWRITE** — premise went stale/false since drafting (re-verify inverted
  the class); block the draft, re-classify from scratch, do not soften.
- **BLOCKED** — PoC needs an auth session/token that is now dead; cannot be
  re-verified => not a pass. Try vault-restore first; if still dead it is
  an operator-gated item, not submittable. **Confirm dead-vs-alive at the
  API, never from the vault age alone** (2026-09-30): load the vault
  cookie-header (`tools/sessions/load_session.py <eng>`) and hit ONE
  authenticated endpoint — a 401/`root.unauthenticated` with an aged harvest
  (Elastic vault was ~36h old, well past the ~1h auth-cookie rotation) means
  the session died server-side and no local replay resurrects it. Only THEN
  is a fresh login/OTP needed, which is an operator red-line: check for an
  already-open auth tab on the dedicated Chrome (`curl :9222/json` — an
  Elastic login tab may already be sitting there) and confirm whether the
  mail provider (Proton) tab is open for the OTP BEFORE asking; if neither
  credentials nor a mail tab are present, hand it to the operator rather than
  guessing. Analytics-only cookies surviving (e.g. `ebtSessionId` present,
  `ec_session` gone) is the tell that only the tracking layer lived.
- **CUT** — already internally N/A'd (didn't reproduce in prior rounds); drop.

Parallelise the cheap layer: unauthenticated live replays (rede-only, e.g.
curl a 307-reflection or an anon POST) do not compete for the NIM/panel quota
and can all run up front; the adversarial panels are the serial bottleneck
(one MAS run can sit 10+ min in a single cycle on a congested NIM day), so
fire them one at a time AFTER the cheap sweep has already culled the queue.
Save the result as a per-draft verdict matrix file (reason per row), never a
flat list. Runnable enumerator: `scripts/retest_submission_queue.sh`.

## Confirmation standard: two layers before any "SUBMETÍVEL" verdict
(2026-09-29, operator directive — see
`references/padrao-confirmacao-adversarial.md` for the full method + worked
examples)

Every submittable claim passes BOTH:

**Layer 1 — live replay, deterministic, same-day, no LLM.** Re-verify the
core request NOW with a negative control in the same run; reproduce the
artifact (minted ID, PII row, CNAME+fingerprint), not just a status code;
compute CVSS with the `cvss` lib (honest scenario AND worst-case, report the
range); dup-check with dates. State exactly what could NOT be re-run today
and why — "confirmed live" vs "evidence from <date>" are different claims
and the report must say which it ships with.

For a CODE-level finding the strongest Layer-1 proof is running the exploit
against a real build in a local container PLUS pinning the vulnerable code
across the claimed version range by source hash — this closes the reviewer's
standing objection that "identical source does not prove end-to-end
exploitability on the shipped version," lets you test the maximal variant
instead of inferring it, and catches logically-broken PoC examples (a glob
example must satisfy the pattern's arity). Full recipe, GPT-6 reviewer
routing, and the severity-asymmetry rule:
`references/live-poc-and-source-verification.md`. Note (tooling): the NIM/
panel 429 does NOT block this — the target build is plain HTTP.

**Layer 2 — adversarial PRO vs CON panels with a convergence rule.** PRO =
honest submission advocate; CON = hostile triager (duplicate, works-as-
designed, speculative impact, inflated severity, out-of-scope). Cycle 2
cross-examination only when they diverge (each side sees the other's closing
argument). **Agreement = CONFIRMED** (SUBMIT/NAO-SUBMIT + severity);
persistent divergence = INDECISO → goes to the OPERATOR with both
arguments — the agent never resolves an INDECISO by silently picking a
side. The CON layer repeatedly catches what TP-unanimous panels miss
(Elastic oracle: panel TP, CON HOLD — "accepted risk" reading; CoinDCX:
drafted Medium, CON honest floor Low). Reference implementation:
`~/tools/T3MP3ST/padrao_confirmacao.py`; per-draft verdict JSONs in
`/tmp/maspadrao_<draft>_veredito.json`. Route panel calls to
`--model opus-4-8` for offensive context (5.5's classifier refuses it).
Run Layer 1 first — it settles most verdicts deterministically and the
panels adjudicate only the contested remainder (free-tier stance runs take
20-40 min each on degraded days; ~6 drafts ≈ one night).

**Panel-liveness pitfall: a reasoning model mid-thought looks identical to a
dead model (2026-09-30).** The MAS panel roster (`~/tools/T3MP3ST/panel_mas.py`
DEFAULT_AGENTS) includes reasoning models (glm-5.3, kimi-k3,
deepseek-v4.1-flash) that emit thousands of chars of `reasoning_content`
BEFORE the first `content` byte. glm-5.3 took **110s** to first content on a
real probe; a 20s liveness curl to it returns TimeoutError and looks dead. Do
NOT conclude "NIM is down" or "model X is dead" from a short-timeout probe, and
do NOT kill a MAS run that has been "stuck" for 20-40 min in one cycle — that
is normal for this roster. A panel child parked in `futex_do_wait` is blocked
on a slow model's HTTP read, not hung. Before declaring a model dead: probe
with timeout >=120s AND a real (non-trivial) prompt AND `max_tokens` >= 2400,
OR stream and watch for the first delta chunk. Genuinely-dead is only: zero
bytes under streaming for 60s+ across retries (deepseek-v4.1-flash showed this
intermittently — cold-start, not permanent). Separate failure mode: kimi-k3
can return HTTP 200 with `content=0`/`reasoning_content` non-empty (budget
consumed by reasoning) — a valid HTTP response but an empty panel vote; the
panel tolerates it as an invalid position (`final_valid/panel`), so it degrades
quietly rather than blocking. To add a model to the panel: add it to the
registry dict with a generous per-agent `"timeout"` (400 for reasoning models)
and append the slug to `DEFAULT_AGENTS`; confirm its exact id from the live
catalog (`GET https://integrate.api.nvidia.com/v1/models`) rather than guessing
the version string. A MAS launched before a roster edit keeps the OLD roster
for its whole run — let it finish; the new roster applies to the NEXT launch.

Attribution drift: before paste, verify the handle in every draft matches the
operator's CURRENT handle — it changed mid-campaign (c0lonello →
`c0lonnello`, 2026-09-28) and older drafts still carry the old spelling.

## Make it not read as AI-written (operator directive, 2026-09-30)

The operator requires submissions to NOT be easily identifiable as AI-written
(basis: Wikipedia "Signs of AI writing"). A triager who smells LLM slop
discounts the whole report. Run a lint pass AFTER drafting, BEFORE the
hostile gate. Reference recipe + full defect taxonomy:
`references/anti-ai-writing-and-self-review.md`. Runnable linter:
`scripts/ai_writing_lint.py <draft.md>` (flags em-dashes, cliches, hedge
stacks, Unicode arrows/bullets, rule-of-three, superficial participles).

The tells that actually show up in security drafts:
- **Em-dash overuse** — the single strongest tell. Target ZERO em-dashes in a
  submission; rewrite as period / semicolon / parenthesis. (A real draft had
  18; every one was removable without losing meaning.)
- **Unicode arrows/bullets** (→, ✓, •) inside prose = formatting-model
  fingerprint. Use words ("returns", "gives") or plain hyphens.
- **Rule-of-three** puffery ("cannot rotate, cannot scope, cannot isolate").
  Cut to the one clause that carries evidence.
- **Hedge stacks** ("may possibly potentially"), synonym-rotation of the same
  noun, and formulaic "In conclusion / It is important to note" openers.
- Voice fix: write first-person past as an experienced researcher would —
  "I re-tested this across sessions", "the key is not a secret in any
  meaningful sense" — with irregular sentence lengths, not uniform cadence.
False positive to ignore: a gerund STARTING a technical bullet
("Replaying the same value against sibling hosts gives...") is fine; the AI
tell is a trailing "-ing" clause that chains empty analysis.

## Self-review defect taxonomy (run as a hostile reader on your OWN draft)

The drafting pass reliably leaves defects the confirm-loop doesn't catch. A
second review pass on the CoinDCX BFF draft found 8; the ones that recur:

1. **Factual self-contradiction** (most credibility-fatal). The draft claimed
   "I limited testing to status codes and response sizes only, did not
   extract data" while the endpoint table listed "rateIds + timestamps" and
   a full JSON body — those ARE body contents. A triager pins this instantly.
   Fix: make the no-extraction claim TRUE ("status, sizes, and enough of the
   response shape to confirm it is the same public market data") or delete
   the over-strong claim. Grep the draft's own restraint claims against what
   the evidence blocks actually show.
2. **Deploy-fragile PoC.** Step 1 hardcoded a Vite bundle path
   (`assets/index-C0evjceN.js`) whose hash changes every deploy. A triager
   testing days later gets a dead link and closes "cannot reproduce." Fix:
   derive the volatile path at runtime
   (`BUNDLE=$(curl -s <site>/ | grep -oE 'assets/index-[A-Za-z0-9_-]+\.js' | head -1)`)
   and note the observed value as "at time of writing."
3. **Count drift.** "Six GET endpoints respond" when the table showed 5×200 +
   1×405. Recount every quantifier against its own list before paste.
4. **Shell-escape corruption from earlier edits.** Doubled `\\` line
   continuations and `%{http_code}\'` artifacts from a prior find/replace
   pass — the PoC won't run as pasted. Always end-to-end replay the PoC
   commands EXACTLY as they appear in the draft (copy from the rendered code
   block, not from memory) as the last step.
5. **Ambiguous labels** ("staging, stage, production" for 3 identical config
   occurrences → "two staging configs, one production config").
6. **Over-precise volatile values are a reproduction trap** (2026-10-01). Any
   number that comes from LIVE data drifts between your capture and the
   triager's re-run; cited byte-exact, it reads as "cannot reproduce" on
   re-test. A CoinDCX draft cited response sizes `62,941` / `260,948 bytes`;
   two re-runs minutes apart gave `62,945`/`261,003` then `62,948`/`261,059`
   (live market-data payloads). Fix: approximate volatile figures (`~63 KB`,
   `~260 KB`) and add one line that the value varies and the STABLE part is
   the behaviour (the 200-vs-403 split), not the byte count. Status codes,
   hashes, and exact-match gate values ARE stable and SHOULD stay byte-exact;
   only quantities derived from changing data get the approximation.
7b. **Glob/regex/wildcard PoC examples must satisfy the pattern's arity.**
   A draft used `team-alpha` as the in-scope positive control under a
   `team-?` grant; `?` matches exactly one char, so `team-?` only covers
   6-char names and `team-alpha` (10 chars) was never in scope — the positive
   control was broken by construction and the live run returned 403 where the
   draft claimed 200. When a PoC leans on a matcher, check every example
   value against the matcher's real semantics before paste; a reviewer who
   knows the engine spots an impossible example instantly. Second instance of the same family (2026-10-17): the corrected ds1 draft stated `team-private (10 chars)` twice when `len('team-private')` is 12, in a report whose whole argument is char arity. Every `(N chars)` label in a matcher-argument report is a checkable claim: count with a script (`python3 -c "print(len('team-private'))"`), never mentally.

7. **Self-reported char/line counts leak and go stale.** A heading that said
   `## Title (99 chars)` was actually 98, and the "(N chars)" note was an
   internal drafting artifact that does not belong in the paste-ready report
   at all. Strip internal meta (char counts, "updated <date>" in headings that
   contradict the report's own date line) before paste.

**Prove what a header/param IS, don't infer it from traffic (kills
"works-as-designed").** The strongest counter to "that gate is just a
rate-limit / abuse filter, working as intended" is the client SOURCE, not
more black-box requests. Grep the public bundle for the USAGE site, not only
the value: alongside `BFF_SECRET:"df568..."` (the literal, 3x) the bundle
also held `Ys(aa,"X-Allow-Id",xe.BFF_SECRET)` — the call that wires the
hardcoded value straight into the `X-Allow-Id` header. That one line proves
the header carries a single static shared value (not a per-user/session id),
so it fails as BOTH an access control AND a rate-limiter, at the source level.
Put the usage grep in the repro steps (`grep -o 'Ys([^;]*X-Allow-Id[^;]*)'`)
and run it live before shipping. General rule: when a finding's severity
hinges on "what is this token/header/param for", recover the answer from the
shipped client code and quote it, rather than arguing from response codes.

Where the external adversarial panel is unavailable (Codex quota exhausted,
Anthropic OAuth 429/expired), do this taxonomy pass yourself as the hostile
reader rather than skipping review — but SAY in the handoff that the external
panel didn't run, so the operator can choose to wait for it.

## Takeover verification: the authoritative-NS descent (2026-09-28)

When an operator demands "100% certainty" on a negative takeover verdict,
the proof that closes it is a DNS descent to the AUTHORITATIVE nameservers
of the CNAME-target zone — not curl signatures and not the apex WHOIS alone
(both were done first and left a real gap the panel reviewer caught):

1. Apex WHOIS: expiry + registrar locks (clientDelete/Transfer/UpdateProhibited)
   kill the "domain expired/claimable" class. Route53 NS suggests the zone
   is actively managed.
2. Walk the delegation chain: dig `+norecurse` against each zone's NS, follow
   the NS-referrals in the AUTHORITY section downward (Route53 → ns1.us-central1.<zone>
   → ns1.gamma.<zone>...) until a server answers with the `aa` flag.
3. The closed proof: `aa` + NOERROR + 0 answers + SOA in AUTHORITY for the
   FINAL target name = record deleted from inside an entirely self-owned
   zone. Takeover by a third party requires a claimable resource OUTSIDE the
   owner's control; a chain that never leaves their domains has none.
4. GPT-6-as-skeptic may vote INCONCLUSIVE simply because ITS sandbox had no
   DNS — feed it your locally-collected WHOIS/dig evidence rather than
   accepting the inconclusive as a finding.
5. Honest residuals to note in the verdict: post-expiry windows (2027/28)
   become monitorable risks, and staging/gamma hosts are policy-excluded
   regardless of technical exploitability.

## Safety gate

Reports must be based on **reproducible evidence** captured during authorized testing. Do not submit a report purely from recon or scanner output without manual verification. For third-party production targets, live exploitation (creating a cloud resource, writing a webshell) requires verifiable authorization (contract, scope, or staging environment). Document the authorization header used (e.g. `X-HackerOne-Research: <handle>`) and the scope reference.

**Scope-declaration rule (operator correction, Essity 14/09):** before touching any surface not yet seen in THIS engagement (new Chrome profile, account registration, traffic to a fresh domain), state in one line how it maps to an in-scope asset and what it's for ("tenashop.de = TENA shop under the Essity VDP; registering own account to close the CORS PoC gap"). `allow_impact=true` authorizes the mechanics, not silence — an un-announced live registration got interrupted mid-flow even though it was squarely in scope. When interrupted: stop immediately and verify actual persisted state (was the account created? session cookies present? cred file written?) before telling the operator "nothing happened" — this time the honest check proved zero persistence (failed client-side validation, 0 Gigya session cookies, no cred file).

### Shared-attribution surfaces: synthetic identifiers only

Some vulns live on channels shared with real third parties: affiliate tracking, referral counters, review scores, ad attribution, leaderboards. Proving impact by submitting events under a REAL third party's identifier (partnerHash, referralCode, userId, reviewer handle) can genuinely harm them — fraud flags on their account, unearned commission that triggers clawback later, ban for "suspicious activity". Even with `allow_impact=true` this is a red-line.

The safe way to prove permissiveness is **synthetic identifiers plus explicit documentation in the report**. Concrete pattern (1win flowmetric, 2026-09-22):

- Loop 20 POSTs against the tracker with `partnerHash="POC-<handle>-<n>"` — fictitious, no collision with real partner IDs.
- Count 2xx responses to measure the true acceptance rate (also catches WAF/rate-limit that the initial one-shot missed).
- In the report, add a paragraph like: *"No third-party partner hashes were used — synthetic identifiers only, to avoid affecting any real affiliate's metrics. The volume test proves the endpoint's permissiveness; a real attacker script would submit valid hashes recovered from the front-end and would achieve the same acceptance rate."*

This preempts the two most common triager objections in one paragraph: (a) "where's your proof?" (the numbers) and (b) "did you cause harm?" (explicit no-harm statement with reasoning). It also lets you SUBMIT without waiting on a full end-to-end payout PoC that may require account registration + manual approval + days of dashboard wait — the finding stands on the permissiveness measurement, and impact remains defensible-but-plausible without overclaiming.

### Never report a false positive (FP-avoidance)

"Real but low-value" is reportable as context; "looks like X but I couldn't prove it" is NOT a finding. When a WAF is bypassable (comment-split passes) AND the app accepts unescaped quotes AND the payload reaches the DB, but **no technique** (boolean / time / error / union / stacked) produces an observable difference across the full test matrix — the honest verdict is **"not confirmed: query is parameterized."** Document the defense-in-depth gap (unescaped input + bypassable WAF) as a hardening note, but do NOT file it as SQLi. Firing a fabricated/overclaimed finding burns a report and your credibility with the triager; a measured "not confirmed despite N techniques" reads as rigor, not failure. Reference the methodology that backs the negative: `hardened-web-target-testing` → `references/sqli-hypothesis-testing.md`.

### Reportable vs policy-low-value triage

Even a confirmed real finding can be closed Informative by program policy. Before investing in a full report, check the policy for explicit de-valuing language:
- "X bypasses will be marked as Informative" (gateway/WAF-bypass products)
- "Business logic errors and misconfigurations are out of scope"
- "Only full hack scenario will be accepted" (isolated vulns won't pay)
- "Output from Automated Scanners without a PoC"

If the program de-values the finding class, still document it (context for the triager + defense-in-depth value), but set expectations and focus energy on what the policy pays for.

## Pre-report: Understanding the program

Before a single request is sent, extract the program's scope and rules.

### Scope extraction via mirror repos

HackerOne program pages are JS-rendered (React). Use mirror repos instead of the browser:

- **`ajaysenr/HackerOne-Disclosed-Reports`** — 10,000+ disclosed reports with metadata (severity, bounty, CWE). Browse by program, severity, year. Individual report bodies in `reports/<ID>.md`.
- **`rix4uni/scope`** — auto-updated scope data per platform. `data/Hackerone/hackerone_inscope.txt` has all in-scope domains. Grep for the program name.
- **BBRadar.io** — program metadata (scope, reward range, response time).

### Program policy analysis

Read the full policy page (not just scope). Watch for these traps:

- **"Secure Gateway Bypasses will be marked as Informative"** — bypassing the platform's security product is explicitly low-value. Focus on apps behind it, not the gateway itself.
- **"Only full hack scenario will be accepted"** — individual vulns (XSS, missing header) are closed. The program wants a chain that edits the index page or downloads the database.
- **"Recorded video must be included"** — the video proves the exploitation **PoC** (the final step), not the whole recon process. A terminal recording (asciinema) of the exploit command + result is acceptable.
- **"Business logic errors and misconfigurations are out of scope"** — don't waste time on business logic flaws.
- **"Do not brute force credentials or guess credentials"** — auth bypass must come from technical flaws, not guessing.
- **"Do not upload shells or create a backdoor"** — exploitation must be demonstrated without persisting access.

### Asset types and vulnerability selection

The HackerOne onboarding wizard filters programs by asset type and vulnerability type. For a web-first stack:

- **Domain, URL, API** — core. Subdomain takeover, CORS, IDOR, XSS, broken auth.
- **CIDR** — mark if comfortable with IP-range scanning, but only attack CIDR when the same program also has web assets in scope.
- **AI Model** — high-growth area, low competition, overlaps with existing AI knowledge (prompt injection, context exfiltration, jailbreak).
- **Smart Contract** — skip unless you have Solidity/Foundry tooling.
