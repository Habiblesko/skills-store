# Writeup corpus analysis — 14,877 disclosed HackerOne reports

Condensed from an analysis of `~/tools/hackerone-reports/data.csv` (14,877
disclosed reports: program, title, link, upvotes, bounty, vuln_type).
Use to prioritize what to hunt and what a report needs to pay.

## Top vuln types (frequency in 14,877 disclosed reports)

| Count | Type |
|---|---:|
| 1,430 | Information Disclosure |
| ~2,280 | XSS combined (generic 983 + reflected 658 + stored 639) |
| 803 | Violation of Secure Design Principles |
| 775 | Improper Authentication |
| 742 | Improper Access Control |
| 511 | CSRF |
| 506 | Uncontrolled Resource Consumption |
| 454 | Privilege Escalation |
| 383 | Business Logic Errors |
| 354 | IDOR |
| 342 | Open Redirect |
| 340 | Code Injection |
| 319 | Memory Corruption |
| 306 | SQL Injection |
| 286 | SSRF |
| 236 | Path Traversal |
| 233 | Command Injection |
| 188 | Cryptographic Issues |

## Top bounties (what actually pays 5 digits)

- $50k — GitHub access token exposure (Shopify)
- $40k — API access to Phabricator on code.uberinternal.co
- $35k — Account Takeover via Password Reset **without user interaction**
- $33.5k ×2 — RCE via GitHub import (GitLab)
- $30k — RCE via npm misconfig (installing internal libs from public registry)
- $29k — arbitrary file read via bulk imports UploadsPipeline (GitLab)
- $25k — SSRF via Analytics Reports; SQLi in report_xml.php; exposed k8s API → RCE
- $22.3k — importing local git repos (GitLab)
- $21k — role escalation by access-list owner

**Pattern: chains (IDOR / privesc / file-read → RCE or ATO) are what pay
5 digits. ATO without interaction is the single highest-value web finding.**

## Programs with most disclosed reports

Mail.ru, U.S. DoD, Internet Bug Bounty, HackerOne, Nextcloud, curl, Shopify,
Node.js third-party modules, GitLab, X/xAI, Uber, GitHub Security Lab,
New Relic, VK, Automattic.

## Local corpus (searchable)

The same data lives locally for keyword search during recon/validation:

- CSV: `~/tools/hackerone-reports/data.csv` (reddelexc/hackerone-reports)
- SQLite corpus: `~/.local/share/pentest-writeups/metadata.db` (built from the
  CSV, table `writeups`: title, content, source, tags, program, bounty,
  upvotes, vuln_type, url) — used by the pentest-agents writeup MCP server
  (`mcp_writeups_search_writeups`, mode `sqlite` keyword search).
- Query tips: phrase queries on title/tags/program work best
  (e.g. `IDOR password reset account takeover`, `SSRF filter bypass`).

## Validation before submitting (7-Question Gate)

From pentest-agents `rules/mistakes.md` — kills weak findings in 30s:

1. Qual é o ativo exato? (URL, endpoint, parâmetro)
2. Qual é o request que prova o bug? (curl, HAR)
3. Qual é o response que prova o bug? (diff before/after)
4. Qual é o impacto real? (dado acessado, ação executada, chain possível)
5. Isto é um falso positivo conhecido? (WAF, CDN, rate limit, feature)
6. Qual a severity (CVSS 3.1 ou 4.0, conforme a plataforma)?
7. Tem PoC reproduzível no alvo vivo?

Any "não" or "não sei" → it's a LEAD, not a report.

## Report-writing lessons from the corpus + mistakes.md

- "CONFIRMED" = working PoC against the live target. Fingerprints,
  status-code differentials, inferred chains are `POTENTIAL`/`LEAD`.
- Demonstrate impact with real data: "Here is the data I accessed" beats
  "could result in...".
- Sibling Rule: test every adjacent endpoint/method/field/alias — 30%+ of
  paid IDOR/BAC bugs are sibling bugs.
- CVSS version must match platform: HackerOne = 3.1; Bugcrowd/Intigriti/
  Immunefi = 4.0. Mismatch = triage rework.
- Write artifacts to disk — terminal output is not evidence.
- Never hallucinate file paths: `ls` every path before citing it in a report.
