# Confirmation Standard — adversarial PRO vs CON with convergence rule (2026-09-29)

Operator directive: "Confirm 100% by running multiple confirmations with
different strategies, one MAS against and one for — considered confirmed
submittable or not when they agree with each other the majority of the
time. Also use the methods we already have — implement this as the
standard."

This file carries the full method; the SKILL.md summarizes it. Both layers
run BEFORE any draft enters the "o que temos submetível?" queue.

## Layer 1 — Live replay (deterministic, no LLM, always first, same-day)

- **Re-verify live**: replay the core request(s) the SAME DAY as the
  submission claim. Old evidence, however strong, goes stale — targets
  ship fixes, rotate secrets, kill endpoints.
- **Negative control** in the same run (fake token / absent param) — proves
  the endpoint still validates state and the 200s are not artifacts.
- **Artifact, not status code**: the concrete thing the report claims
  (visitorId minted, PII row, CNAME + canonical fingerprint), reproduced
  today.
- **CVSS computed** with the `cvss` lib — never a number from memory.
  Compute the honest scenario AND the worst-case; report the range with
  reasoning (e.g. CoinDCX BFF: 0.0 if C:N / 5.3 if C:L / 5.8 worst-case).
- **Dup-check** against disclosed reports, keyword set + dates recorded
  in the draft.
- **State what could NOT be re-run today and why** — "confirmed live" vs
  "evidence from <date>" are different claims; the draft must say which
  one it ships with.

Worked examples (all 2026-09-29):
- 1win flowmetric: POST unauth → **201** with fresh visitorId/clickId
  minted — submittable the same hour.
- CoinDCX BFF: matrix 4/4 intact (200-with-secret / 403-without) — matrix
  intact ≠ impact; severity stays Low, HOLD pending a non-public GET.
- Essity v4: 4 CNAMEs re-resolved to azurefd tombstones + canonical 404
  fingerprint.
- Wolt RT-reuse: endpoint alive + negative control 401 — but the rotation
  chain itself blocked behind a phone step-up (operator red-line), so the
  draft ships on dated evidence WITH the limitation stated.

## Layer 2 — Adversarial PRO vs CON panels (the operator's design)

Two independent LLM panels over the SAME draft:
- **PRO** = submission advocate: strongest HONEST case — what the evidence
  proves (never inflated), why not a duplicate, CVSS justification. An
  honest advocate concedes a weak finding.
- **CON** = hostile triager: duplicate-known, works-as-designed,
  speculative impact, inflated severity, insufficient evidence,
  out-of-scope — every real reason a program closes without paying.
  Concedes only if the finding survives.
- **Cycle 2 cross-examination ONLY if they diverge**: each side sees the
  other's closing argument and revises its verdict.
- **Convergence rule: agreement = CONFIRMED** (SUBMIT or NAO-SUBMIT with
  severity); persistent disagreement = INDECISO → goes to the OPERATOR
  with both arguments. The agent never silently resolves an INDECISO by
  picking a side.

Reference implementation: `~/tools/T3MP3ST/padrao_confirmacao.py` (wraps
panel_mas.py with the two stance preambles; per-draft verdict JSON in
`/tmp/maspadrao_<draft>_veredito.json`). Model routing: Opus 5.5's
classifier REFUSES offensive pentest context — route adversarial review to
`--model opus-4-8`.

## Honest verdicts beat favorable ones (validated 2026-09-28/29)

CON-verdicts that changed the queue:
- Elastic oracle (differential 400/403 membership enum): **HOLD** — reads as
  "accepted risk" at Medium/Low; reputational cost of an N/A outweighs the
  submit. (A TP-unanimous panel had missed this — the CON layer earns its
  keep exactly here.)
- CoinDCX BFF (CWE-798): **HOLD** — secret real, unlocked content
  public-by-nature; needs a non-public GET to move past "elegant N/A".
- 1win flowmetric: **SUBMIT** — unauth + concrete artifact + monetary-fraud
  angle; anchor `payout manipulation` in the Summary, not just tracking.
- Elastic DS1 (wildcard authz): **SUBMIT** — runtime PoC self-sufficient;
  the `?`-glob precondition is admin-idiomatic, NOT a misconfiguration
  (that caveat closure killed the last objection).

Severity calibration: computed CVSS = ceiling; the CON panel = the floor the
triager will argue; report between them, leaning LOW.

## Pitfalls running the standard

- Free-tier stance runs take 20-40 min each on degraded NIM days
  (glm-5.3 at 60-200s/request). Budget one night for ~6 drafts.
- Set the per-stance subprocess timeout (5400s), not just an outer loop
  timeout — otherwise the process dies `exit=124` mid-cycle and you lose
  the debate transcript.
- **Hung panel vs slow panel (2026-09-30): diagnose at the process level, do
  NOT just wait.** A MAS sat 23 min in "ciclo 1" — not slow, the NIM endpoint
  itself had stopped answering mid-request. Distinguish the two: (a) check
  whether the cycle already wrote partial output — `ls -t /tmp/mas_adv_*.md`;
  if `pro1`/`con1` exist, that side FINISHED and the other is stuck; (b) grep
  each side file for `POSICAO_FINAL` — a file that is only the echoed prompt
  with no verdict = that stance hung; (c) inspect the stuck child's syscall
  — `cat /proc/<pid>/wchan`; `futex_do_wait` = blocked on a network call that
  will not return; (d) probe NIM directly with a 3-token request and a 20s
  timeout — if that also hangs/`exit=124`, the endpoint is down, not your
  code. When NIM is down, do NOT fire more panels (they stack identically
  hung); either wait for it to recover, or switch the panel backend to an
  OmniRoute free (gemini-flash-lite / nemotron-lightning) — the operator's
  rule permits "this method or a better one", and single-provider dependence
  on a flaky NIM is the fragility to design out. The PRO side finishing with
  a verdict (e.g. SUBMIT-Medium) while CON hangs is NOT a convergence — an
  unfinished CON is INDECISO-by-timeout, never a silent SUBMIT.
- Both panels see the SAME draft text; cross-examination exchanges
  ARGUMENTS, never new evidence — new evidence goes back to Layer 1.
- INDECISO is a valid outcome, not a failure — the operator decides with
  both arguments in hand.
