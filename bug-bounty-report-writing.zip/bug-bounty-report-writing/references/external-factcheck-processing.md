# External fact-check processing — worked example (Elastic ds1, 2026-10-17/18, THREE review rounds)

Context: operator routed the ds1 draft (Elasticsearch ES|QL Data Federation datasource wildcard authz bypass, 9.5.x) through GPT-6, then GPT-6.1 twice. Round 1 = claim-by-claim critique of the draft; round 2 = documentary review of the closure; round 3 = reservations on the second closure. All critiques were triaged against disk BEFORE editing (procedente / refutable-with-evidence / genuinely-unverified).

## Round 1 — 11 procedente corrections
1. `z`-example: `z` (1 char) is INSIDE the `["?"]` scope — it proved response SHAPE, not boundary crossing. Real boundary proof: team-private (12 chars) + team-alpha (10) returned under a `team-?` role (6-char matcher).
2. CVSS 4.3 = Medium per FIRST v3.1 (Low ends at 3.9). Fixed: report Medium per the math, defer calibration to triage with named grounds (metadata-only, experimental flag).
3. "never stored in the clear" was FALSE vs official docs: `cluster.state.encryption.required: false` allows unencrypted credential storage (log warning only). What blocks leakage is response masking `::es_redacted::`. Cite masking as documented behavior + the 503 as the DEFAULT-config guard, not as impossibility.
4. "Writes are not affected" too broad → scoped to what was tested: PUT and DELETE returned 403 in this configuration; authorized-DELETE internal expansion NOT tested.
5. `main` "byte-identical" → pinned to commit (main is mobile): md5 60acc62e... identical v9.5.0–v9.5.5 AND main@08f55f4 verified live via raw.githubusercontent.
6. Enterprise license requirement added to preconditions. (Round-1 text wrongly said "local run used the default trial image" — round 2 refuted this: docker default is `basic`, trial requires explicit `xpack.license.self_generated.type: trial`, and `GET /_license` was never captured. Final wording: license state "not captured rather than presumed", capture added to the PoC script.)
7. "documented glob `?`" → source-verified acceptance: `?` not specifically documented for `data_source.names`; StringMatcher.Builder routes any `?`-containing pattern into the automaton path silently.
8. "Everything below is a real HTTP response" → "excerpts from the captured runs; full bodies in attached evidence files".
9. "program-mandated alias" → own alias (policy does not mandate it).
10. Title 190 → 125 chars (H1 caps at 128).
11. Environment line: 8 vCPU / 7.7 GB host stated explicitly (program minimum 1 CPU / 2 GB).

## Round 1 — critiques refuted with on-disk evidence the reviewer lacked
- "Could not confirm the policy class" → live Jina capture `evidence/policy-fresh-jina-2026-10-17.md` ("Access to unauthorized data as authenticated user" verbatim).
- "Core Ineligible list not checked" → `evidence/ineligible-list-8494488-2026-10-17.md`: none of the 4 categories covers an authz bypass with demonstrated boundary crossing.
- "Dup-check pagination unverified" → `evidence/dupcheck-ds1-wildcard-2026-10-15.md`: GraphQL team:("Elastic"), 11x100 pages, 20 disclosed, 23 terms, NO-DUP.
- "Functions as exact cause unconfirmed" → source on disk: TransportGetDataSourceAction.java line 68 `Regex.simpleMatch(pattern, entry.getKey())`; buildRequestPredicate + StringMatcher read line-by-line.
- "File identity across tags unconfirmed" → md5 re-verified live during the closure.

## Round 2 — the closure summary itself was overclaimed (5 material points)
1. **Panel composition**: all 6 MAS transcripts said `posições válidas: 1/2` (judge slot A UNAVAILABLE every cycle) = DEGRADED panel; "validação adversarial completa" in the nightly summary was an overclaim. Fixed: `panel_note` recorded in state.json, nightly report superseded.
2. **Arbiter oscillation**: CON3 arbiter's first raw turn was `EXISTENCIA: refutado / POSICAO_FINAL: NAO-na` with real grounds (works-as-designed, theoretical impact), discarded on a FORMAT re-ask, second turn = Medium. The earlier "template echo" dismissal was wrong — both turns now recorded.
3. **License presumption**: "default image license (trial)" had no basis — `GET /_license` never captured; docs: default `basic`, trial needs explicit set. Fixed: "not captured rather than presumed" + capture in PoC script.
4. **Settings-combination as fact**: the draft presented out-of-scope-with-populated-settings as observed; the poc-live evidence itself marked it PENDENTE. Fixed: the two observed facts (out-of-scope name/type/description crossed; populated settings returned in full) stated separately from the expected combination, labeled inference.
5. **Dup-check overclaim + "GA"**: "rules out public duplicates" → "no duplicate identified by a reasonable-term search (titles + ~600-char summaries)"; internal evidence file said "datasource GA" where the feature is experimental.

## Round 3 — reservations on the second closure (all accepted)
1. **MAS re-run is not a validity requirement** — complements only; repeating debate until favorable consensus = bias. Readiness criterion redefined: claims-compatible-with-evidence + environment-documented + limitations-explicit.
2. **File identity ≠ behavior** — version-range claims relabeled as inference in the code section and the Local-Docker objection (run only on 9.5.3).
3. **Literal passwords** — PoC script rewritten: creds parsed from 0600 file, truncations removed (full captures), flag queried in persistent+transient+defaults, global PASS/FAIL validation with explicit criteria and exit code. (Creds were disposable container --rm values; exposure low but the fix stands as the pattern.)

## Durable rules (all encoded in SKILL.md §"Processing an external fact-check")
1. Triage every critique row against disk before editing.
2. Grep official docs before impossibility/absolute claims; separate encryption-at-rest from response masking.
3. Material rewrite invalidates earlier validation → re-run lints + gate on the current text.
4. Char counts in matcher arguments are scripted, never mental.
5. Verify panel composition from transcripts (`posições válidas: N/M`) before describing validation strength; record arbiter re-ask oscillations.
6. Observation / inference / pending stay separated in report text.
7. Environment facts are captured or labeled not-captured — never presumed.
8. Dup-check phrasing: method-limited ("no duplicate identified by this method"), never exclusionary.
9. Readiness = evidence-shaped criterion; MAS/dup-check re-runs are complements, not certificates; no acceptance prediction.
10. PoC scripts: no literal creds, no truncation, global PASS/FAIL exit.

## Artifacts (engagement-elastic)
- Draft (post-3-rounds): reports/submission-datasource-wildcard-authz.md
- Closure report (superseded twice, final state inside): reports/nightly-ds1-factcheck-closure-2026-10-17.md
- MAS transcripts: loop/evidence/mas-adv-ds1-1018-0313-{pro,con}{1,2,3}*.md, loop/evidence/mas-adv-ds1-full-verdict-2026-10-18.md
- Policy/ineligible captures: evidence/policy-fresh-jina-2026-10-17.md, evidence/ineligible-list-8494488-2026-10-17.md
- Complementary PoC script (docker-approval-gated; sanitized per round-3): evidence/scripts/poc-complementar-ds1-2026-10-17.sh + evidence/creds-elastic-local.md (0600)
