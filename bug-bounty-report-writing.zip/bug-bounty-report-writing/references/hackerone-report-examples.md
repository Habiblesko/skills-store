# Real Disclosed Reports — Anatomy Study

Condensed notes from dissecting accepted HackerOne reports (2026-08 study) and the
HackerOne Quality Reports guide. Use as reference when writing a submission.

## Sources

- HackerOne Quality Reports guide: https://docs.hackerone.com/en/articles/8475116-quality-reports
- HackerOne report templates: https://docs.hackerone.com/en/articles/8496338-report-templates
- PoCcraft rejection guide: https://poccraft.com/blog/how-to-write-a-bug-bounty-report/
- Disclosed reports mirror: https://github.com/ajaysenr/HackerOne-Disclosed-Reports

## HackerOne Quality Reports guide — required content

1. Clear, concise **title** summarizing the vuln ("Stored XSS in user profile field allows script execution on profile view" not "XSS").
2. **Detailed steps to reproduce** — numbered, with URLs, affected params, roles required.
3. **Expected vs Actual behavior** — what should happen vs what actually happens.
4. **Impact** — how an attacker exploits it and what damage it causes.
5. **Supporting material** — screenshots, screen recordings, code snippets of payloads.
6. **Remediation suggestions** (optional but helpful).

Common mistakes: vague reports, missing impact explanation, poor formatting, overloading with irrelevant details.

## Report #426165 — Zomato CORS ($550, 243 votes, Resolved)

Full body: `reports/426165.md` in the mirror repo.

**Title:** `[www.zomato.com] CORS Misconfiguration, could lead to disclosure of sensitive information`

**Why it won:**
- Standard CORS policy explanation paragraph (what CORS is, why ACAO+credentials=true is dangerous)
- Full raw HTTP request INCLUDING Origin header + full Cookie header
- Full raw HTTP response including `Access-Control-Allow-Origin: developersxzomato.com` and `Access-Control-Allow-Credentials: true`
- **Hosted live PoC page** at an attacker-controlled domain (developersxzomato.com) — proves exploitation end-to-end
- Console JS PoC: `XHR with withCredentials=true` to read user info
- Explicit note: "I injected Origin: X and got ACAO: X back"
- Impact: victim's personal info recorded on attacker's server when logged in

## Report #661751 — Starbucks Subdomain Takeover (High CVSS 8.4, 122 votes, Resolved)

Full body: `reports/661751.md` in the mirror repo.

**Title:** `Subdomain takeover of d02-1-ag.productioncontroller.starbucks.com`

**Why it won:**
- `dig` output showing the vulnerable CNAME (NXDOMAIN pointing to `*.cloudapp.net`)
- **Actually created** the Azure Cloud Service with the claimed name (full proof)
- **Uploaded a crafted website** to the claimed service
- **Viewed it live at the victim subdomain** — link to `/poc-2sKR4C.html`
- How it was found: enumeration + DNS record analysis
- Recommendations: remove DNS record / claim domain in a permanent record

## Report #2332728 — Publitas CORS (Resolved, 3 votes)

Full body: `reports/2332728.md` in the mirror repo.

**Why it resolved (minimal but sufficient):**
- Summary explaining ACAO+credentials risk
- Full request with Origin + Cookie + Response with reflected ACAO and `Access-Control-Allow-Credentials: true`
- HTML PoC page with XHR withCredentials + button

## Pattern extraction

For CORS reports specifically, the winning reports all include:
1. The raw **request** with the attacker `Origin:` header.
2. The raw **response** showing `Access-Control-Allow-Origin: <reflected>` + `Access-Control-Allow-Credentials: true`.
3. A **usable PoC** (HTML/JS) the triager runs against a victim session.
4. Impact naming the actual data exposed (profile, orders, addresses).

For takeover reports, the winning reports include:
1. `dig +short CNAME` output.
2. The exact deleted-resource fingerprint string.
3. Either a live-claimed PoC OR the registration chain documented.
4. Impact: phishing, cookie theft, credential harvesting on brand subdomains.

## HackerOne API tips (for studying reports)

```bash
curl -s https://hackerone.com/reports/<ID>.json   # metadata only (no body)
```

Report bodies are JS-rendered on hackerone.com — the GitHub mirror
`ajaysenr/HackerOne-Disclosed-Reports` (`reports/<ID>.md`) is the reliable way
to read full accepted bodies.
