# Evidence pitfalls: Azure takeover claims & CORS authenticated impact

Condensed from the Essity VDP review (2026-09-14), where a polished High/CVSS-8.1
takeover draft and a Medium CORS draft were both stopped at the pre-submission gate.

## Azure Front Door takeover — state of knowledge (as of 2026-09)

- **can-i-take-over-xyz current README:** the "Microsoft Azure — Vulnerable" row lists
  cloudapp.net, azurewebsites.net, blob.core.windows.net, azure-api.net, azurecr.io,
  azureedge.net, etc. — `azurefd.net` is NOT in the vulnerable list anymore.
  CloudFront row = "Not vulnerable". Verify live before quoting:
  `curl -s https://raw.githubusercontent.com/EdOverflow/can-i-take-over-xyz/master/README.md`
  (GitHub search API on the repo also finds zero azurefd commits).
- **AFD endpoint name reuse** (Microsoft Learn, articles/frontdoor/endpoint.md):
  reuse scope per endpoint — `TenantReuse` (DEFAULT): deleted endpoint's domain label can
  be reclaimed within the same Entra tenant; also SubscriptionReuse / ResourceGroupReuse /
  NoReuse. Not documented that an unrelated tenant can grab a deleted modern-AFD endpoint name.
- **Custom-domain attach** (articles/frontdoor/front-door-custom-domain.md): validation is
  via an `afdverify.<domain>` CNAME pointing to `afdverify.<endpoint>.azurefd.net` — an
  existing dangling CNAME at the plain hostname does NOT by itself pass ownership validation.
- **Reservation semantics** (articles/security/fundamentals/subdomain-takeover.md): during
  a post-deletion reservation only the original tenant's subscriptions can claim; after it,
  any subscription can (documented per-service — e.g. classic Cloud Services 7 days; ACR
  automatic reservation). No fixed public window documented for Front Door; Classic-FDN
  vanity names (e.g. `cd-analytics-eu`) may behave differently from modern hashed endpoints
  (`xxx-hash.a01.azurefd.net`) — cannot distinguish from outside without a claim attempt.
- **Defensible report shape when only dangling + 404 are proven:** submit as dangling-DNS /
  configuration hygiene (Low/Informative at impact-based programs), or run a controlled claim
  PoC first. Multi-day identical fingerprint persistence (e.g. 13 days) is a real fact that
  kills the "temporarily unavailable" reading — use it. Do not write "any Azure account can
  claim" or "CNAME passes validation" without the above checks.

## CORS on SAP Commerce (Hybris) OCC APIs — the bearer trap

- Symptom: `Access-Control-Allow-Origin: <any origin>` + `Allow-Credentials: true` reflected
  on 200 public endpoints and 401 on `/occ/v2/<site>/users/current`.
- Reality check before claiming "logged-in PII readable cross-origin":
  - 401 carries `WWW-Authenticate: Bearer`; storefront authenticates against
    `/authorizationserver/oauth2/*` (OAuth code+PKCE flow) and keeps the token in app
    state — the only cookie from the API host is a `ROUTE` load-balancer cookie (HttpOnly,
    no session), JSESSIONID is scoped to `/authorizationserver` only.
  - => a victim's session is NOT replayed by `fetch(..., {credentials:'include'})`;
    header reflection alone proves misconfiguration, not data exposure.
  - Preflight `Access-Control-Allow-Headers: authorization` means a cross-origin page COULD
    replay a bearer it somehow possesses — but possessing it is not the victim-browser
    primitive; don't blur the two.
- To make the finding real: register your OWN shop account, log in, serve a local evil page,
  capture a 200 + own PII in the evil page's console (HAR + screenshot as supporting
  material). Custom research header must NOT be sent from the page (preflight 403s unknown
  headers) — note this in reproduction steps.
- CVSS for confirmed credentialed CORS read: S:U variant (victim's own session, no privilege
  boundary crossed) — e.g. `AV:N/AC:L/PR:N/UI:R/S:U/C:H/I:N/A:N` = 6.5, not 6.1-with-S:C.

## Re-verify can FLIP the finding class, not just refresh it (Essity, 2026-09-30)

A draft marked `submission-takeover-FINAL-v4` (7 Essity/TENA hosts, premise:
"CNAME -> DELETED Azure Front Door, NXDOMAIN, dangling 13 days") was re-checked
live before running the confirmation panel. The premise had INVERTED between
09-14 and 09-30:

- 09-14 state: hosts NXDOMAIN across 3 resolvers, AFD deleted -> classic dangling.
- 09-30 state: the SAME 6 hosts now RESOLVE. `dig +short CNAME` returns
  `smartcare-id-*.a01.azurefd.net` / `cd-analytics-eu.azurefd.net`, the A chain
  walks to live Azure anycast IPs (150.171.110.x), and the canonical AFD endpoint
  answers `HTTP 404` with the body `The resource you are looking for has been
  removed, had its name changed, or is temporarily unavailable.` (vanity Classic
  endpoints answer `404 {"message":"Resource Not Found"}`).

What this means: the endpoint DNS is live again but has no route/origin configured.
The finding is no longer "NXDOMAIN dangling"; it is "AFD endpoint present, no route"
(a different can-i-take-over fingerprint, possibly still reclaimable, but a DIFFERENT
claim requiring different evidence and severity). The v4 draft's core sentences are
now FACTUALLY FALSE.

Rules this enforces:
1. **A draft filename saying FINAL/v4/ready means nothing.** The gate is a live
   re-verify on submission day, every time, no exceptions — a "finished" takeover
   draft is the single most dangerous kind because its confidence invites a
   paste-without-checking.
2. **When re-verify contradicts the premise, BLOCK the draft; do not soften it.**
   Record the delta as a proven claim in the engagement state
   (`cla_*_dns_delta`) with the raw dig+curl evidence, log a SUBMIT-BLOCKER, and
   re-classify + re-run the confirmation panel from scratch. Editing the old draft
   to "mostly fit" the new reality smuggles stale framing into a fresh finding.
3. **The flip direction matters for the class.** azurewebsites/AFD names that were
   dead can come BACK (name re-reserved, endpoint recreated without a route),
   and live custom-domain hosts can go dark — always dig CNAME + A + curl the
   canonical target the same day, and read the 404 BODY (removed-vs-not-found
   distinguishes AFD-no-route from a truly absent endpoint).

Runnable re-probe for a host list: `scripts/retest_dangling_dns.py` (dig CNAME/A
across 3 resolvers + curl the canonical AFD target, dumps JSON).

## Program-scope capture recipe (H1 is JS-rendered; anonymous fetch = 429)

Reuse the logged-in dedicated Chrome over CDP (:9222): find an existing page tab or navigate,
wait ~8s, `document.body.innerText` — save verbatim to `evidence/h1-policy-full-verbatim-*.txt`
and quote the exact Open Scope sentence in the report's Supporting Material. A brand-new
`PUT /json/new` tab may return an empty body — don't conclude "no policy" from one read.
