---
name: finding-validation-supergate
description: "Use when finalizing any finding, report, or claim."
version: 1.4.5
author: c0lonnello, Hermes Agent
license: MIT
platforms: [linux, macos]
category: cybersecurity
metadata:
  hermes:
    tags: [validation, verification, adversarial, panel, submission, gate, false-positive, convergence]
    related_skills: [bug-bounty-finding-validation, bug-bounty-report-writing, curiosity-loop]
---

# Finding Validation Supergate

The single, authoritative, ORDERED pipeline for verifying any assertion before
it is called done: a finding, a report/submission draft, a claim in an
engagement state, or a non-trivial technical conclusion. It chains every
validation method proven in this operation into one gate. EVERYTHING HERE IS
FREE (NIM/OpenRouter free tier, local, OAuth) — the constraint is latency and
the NIM ~40rpm ceiling, never money, so NEVER drop a layer, a judge, or a
round to "save cost". Default to MORE judges and MORE rounds, not fewer. The
step order (deterministic before LLM panels) exists for one reason only: a
panel run on a false premise (stale PoC, evidence that is not on disk) wastes
20-40 min validating something Step 0 would have killed in seconds. Order is
about not wasting TIME on garbage input, not about rationing calls. It does
NOT replace the deep
mechanics in `bug-bounty-finding-validation` (Protocol D panel internals) and
`bug-bounty-report-writing` (report formula, 5-pass review, anti-AI lint,
hostile gate) — it SEQUENCES them and makes running them obligatory.

Operator directive this encodes (2026-10-02): "com base em todos os metodos de
verificacao de falhas/aprimoramento, crie um melhor do que todos e torne
obrigatorio rodar em determinadas situacoes."

## When to Use — Mandatory Triggers (run the full gate, no exceptions)

1. About to call a finding/report/submission "ready", "submittable", "done",
   "100%", or "confirmed".
2. Operator asks "posso submeter?", "o que temos submetivel?", "esta pronto?",
   or any go/no-go on a finding.
3. Marking a claim `proven`/`confirmed` in an engagement `loop/state.json`.
4. Proposing a submit-class next_action that points at a draft file.
5. Asserting a non-trivial technical conclusion the operator will act on
   ("exploitable", "N/A", "the session is dead", "the API changed").

For a lightweight assertion (trigger 5, low stakes) the MINIMUM is Step 0 +
Step 5 (>=2 cycles) — but since everything is free, prefer the full gate even
here when time allows. For anything headed to a human as "submittable", run
ALL steps, always. Because cost is not a factor: run the MAXIMUM viable set of
judges in Step 5 (every live model in the fleet, not a quorum), rotate the
questioner across all of them in Step 4's indefinite loop, and add the
external angle (GPT/Codex, Opus critic, Strix) whenever the quota is up — more
independent eyes is strictly better when it is free. The only reasons to run
fewer are a dead/degraded model or the NIM rpm ceiling (stagger launches, do
not drop judges). NEVER declare done by single-model self-assessment. NEVER
skip Step 5. If the adversarial layer genuinely cannot run (fleet down), say
so explicitly in the handoff rather than lowering the bar.

## THE GATE (deterministic first so panels never run on a false premise; it is all free, so run every layer in full)

### Step 0 — Live replay with negative control (deterministic, no LLM)

Re-run the core PoC NOW, same day, from clean state, WITH a negative control in
the same run. The gate is the DIFFERENTIAL: control fails, exact input passes,
one-char-off fails again. Reproduce the ARTIFACT, not just a status
code. Script a `relive_<x>.sh` in engagement `tools/`. Re-verify can INVERT
the class (Essity `-FINAL-v4` claimed AFD deleted; hosts resolved live = other
class) — if the replay contradicts the premise, BLOCK and re-classify, do not
soften. Dead auth session = SUBMIT-BLOCKER; confirm dead-vs-alive at the API
(load vault cookie, hit one authed endpoint), never from vault age. Volatile
numbers (live payload sizes) get approximated (`~63 KB`); status codes/hashes/
exact-match gate values stay byte-exact. If Step 0 fails/inverts, STOP.

**PUBLIC-PARITY CHECK (2026-10-15, mandatory for any claim of the form "X is
hidden/behind-login/confidential and the API exposes it")**: before any panel
runs, deterministically render EVERY plausible PUBLIC route that could show
the same data — in a real JS-executing browser (CDP `:9222`, `location.href`
nav + `Runtime.evaluate` innerText), never curl/Jina alone. Two live proofs:
(1) 2026-10-15 the referral-rewards draft claimed the 6-level reward table was
auth-only; its negative control tested `/en/referral-program` (login redirect)
while the actual public route `/en/page/referral-program` rendered the exact
same table anonymously (6/6 segment match, no login wall) — claim refuted, 0
NIM calls spent, report parked. (2) The original claim `cla_gql_referral_promo_anon`
had ALREADY been closed N/A-by-design 01/10 with the same positive control —
the draft written hours later ignored it. Rules: (a) SPA landing pages return
empty/zero values to non-JS fetchers (Jina showed "earn 0"; only the rendered
DOM had the table) — curl/reader text is NOT evidence of what the page shows;
(b) grep the engagement state/history FIRST: a claim closed as N/A-by-design
with a positive control is a hard precedent — any new draft of the same
surface must address it or die at Step 0; (c) edge-blocked curl (CF 403 on
datacenter IP) does not equal auth-required — control both reads through the
same JS browser; (d) route-variants are cheap to enumerate
(`/page/<slug>`, `/<lang>/<slug>`, marketing/support/blog hosts) — a single
wrong-route negative control proves nothing about the surface. If a public
route shows the same data, the finding is N/A-by-design: park the draft with a
REFUTADO stamp + ledger `status=refuted`, never spend panel calls on it.

### Step 1 — Evidence-artifact audit (deterministic)

Every concrete claim maps to a raw file on disk. Grep the draft's specifics
(IDs, counts, ranges, dates) against `evidence/`. Missing artifact + live
session => re-run and save now. Missing + dead session => CUT the claim. A
verifier with a HARDCODED input path silently validates the WRONG file — make
targets a CLI arg and cross-check a cheap invariant (byte count, a string you
just changed). If a lint flags a phrase you already removed, suspect the reader.

### Step 2 — TP/FP truth check (Protocol D panel, reasoning-aware)

Is it a real exposure at all? Run the multi-model panel (v2 reasoning-aware, or
v3 with the Opus submission-critic ladder) per `bug-bounty-finding-validation`.
TP != reportable. Feed the panel the EVIDENCE (HTTP responses, curl, JS),
never a bare description. A split verdict is often two FRAMES (mechanism vs
policy/impact), not a factual disagreement — that reframing is the signal.

### Step 3 — Eligibility, scope, duplicate (biggest N/A sources)

`bug-bounty-report-writing` 5-pass gate, Passes 1-2: pull the program's LIVE
policy AND HackerOne Core Ineligible Findings list
(`docs.hackerone.com/.../8494488`) via the logged-in `:9222` browser
`.innerText` (NOT web_extract). In-scope != eligible class; quote the
program's OWN rule for the class verbatim. Dup-check disclosed hacktivity for
the asset's distinctive terms. Cross-check EVERY host against local
`scope/scope.csv`, not memory; open-scope => prove ownership from the app.

### Step 3.5 — Freshness gate: scope STILL active + embargo/disclosure window (deterministic)

Added 2026-10-03 after the validator01 self-run: the panel diverged (PRO
SUBMIT-low vs CON NAO-medium, GATE iMAD material=True) on exactly one real
hole both sides named — the gate proved a finding TRUE and well-written but
not that it is STILL submittable AT THIS MOMENT. Technical correctness is not
freshness. Before declaring submittable, confirm three time-sensitive facts
and record each with a timestamp + timezone:

1. Scope still active NOW. `scope/scope.csv` is a cached snapshot; re-pull the
   program's live scope table (logged-in `:9222` `.innerText`, same as Step 3)
   and diff against the local CSV. An asset dropped from scope since the last
   download = submit-BLOCKER, not a soft note. If the live pull fails, say so
   and treat scope as UNVERIFIED (do not assume the cache is current).
2. No embargo / responsible-disclosure window open. Check the program policy
   for an active embargo, coordinated-disclosure period, or "do not report X
   class right now" freeze. A technically valid finding under embargo =
   BLOCK + hold, never submit.
3. Program still accepting the class/live. Confirm the program is not paused,
   not migrated off the platform, and the reward/handling table has not
   flipped the class to ineligible since Step 3 read it.

This step is cheap (one extra live read + a diff) and fail-closed: any of the
three UNVERIFIED or stale = the finding is NOT submittable until re-confirmed,
regardless of how strong Steps 0-5 are. Scope/policy drift is silent; the only
defense is reading it fresh at validation time, not trusting a prior snapshot.

### Channel-integrity rule (TRANSVERSAL — applies to every live read in Steps 0, 3, 3.5)

Added 2026-10-03 after the validator01 recursive self-run (v1.1.0): the panel
agreed the freshness hole was closed, then named a DEEPER one both framings
accepted — every "live truth" read trusts `:9222 .innerText` / the local
browser WITHOUT proving the response is fresh and un-tampered. A cached DOM, a
`304 Not Modified`, or a proxy that injects content makes the gate validate
against stale/forged data while believing it read live. "I re-pulled it" is not
"I proved it was fresh". So any read the verdict depends on must carry a
freshness/integrity proof, recorded alongside the value:

1. Defeat cache explicitly. Append a nonce/timestamp cache-buster to the URL OR
   send `Cache-Control: no-cache` + `Pragma: no-cache`; confirm the response is
   a FRESH `200`, never `304`/from-cache/`disk cache` in the Network entry.
2. Prefer the authenticated API/network response over scraped DOM when both
   exist — read the actual HTTP response (status + body + headers) via CDP
   Network, not just rendered `.innerText`, which can be a stale render or
   injected node. When only DOM is available, capture it via a fresh
   `Runtime.evaluate` after a real reload, not from a tab that may be cached.
3. Pin an anti-stale marker. Diff a value that MUST change between reads (a
   server date header, a rotating token, a counter) to prove the read is not a
   replay of a prior snapshot; if nothing changes and nothing should be
   constant, treat the read as UNVERIFIED.

Fail-closed: a live read without a freshness/integrity proof is UNVERIFIED, and
UNVERIFIED blocks "submittable" exactly like a stale scope does. This does not
add a panel round — it is a cheap discipline on reads the deterministic steps
already perform.



### Step 4 — Hostile self-review + anti-AI lint (deterministic + hostile read)

`bug-bounty-report-writing` 5-pass gate, Passes 3-5 + self-review defect
taxonomy. Read your draft as a triager closing it: factual self-contradiction,
deploy-fragile PoC (derive volatile hashes at runtime), count drift,
shell-escape corruption, ambiguous labels, over-precise volatile numbers,
leaked internal meta. When severity hinges on what a header/param IS, prove it
from the shipped client SOURCE and quote it (the
`Ys(aa,"X-Allow-Id",xe.BFF_SECRET)` usage-grep that killed
"works-as-designed"), not from response codes. Run the anti-AI linter
`~/.hermes/skills/security/bug-bounty-report-writing/scripts/ai_writing_lint.py`
or the engagement `ai_lint_3009.py`: ZERO em-dashes, zero Unicode
arrows/bullets in prose, no rule-of-three, no hedge stacks. Then mechanical
consistency: attribution == `c0lonnello` (2 N), CWE, dates, secret/hash
identical everywhere, title <=100 chars, no editorial notes.

### Step 5 — Adversarial confirmation to STRICT convergence (mandatory close)

PRO vs CON panels iterate until they agree, judged by an INDEPENDENT blind
arbiter, never by the drafting model. Two acceptable convergence shapes:
(a) indeterminate rounds until consensus, or (b) N consecutive rounds with no
divergence (operator preference, 2026-10-02). Harness:
`~/tools/T3MP3ST/mas_adversarial.py <draft.md> [cycles]`.

**MANDATORY DEEP MODE (2026-10-12, operator: "discutir o pq dos argumentos
do outro indefinidamente ate entrarem em um consenso")**: every Step 5 run
MUST use the DEEP harness, not just the cross-debate. Deep = 
`mas_adversarial_deep.py <draft.md>`, which sequences:
  1. `mas_adversarial.py` cross-debate (1 round PRO vs CON)
  2. `debate_deep.sh <draft>` — INVENTARIO completo de motivos (PRO + CON)
     listados NUMERADOS ('PRO1', 'CON2', ...);
  3. Loop ponto-a-ponto: para CADA motivo, 3 chamadas independentes —
     (a) defesa do PRO, (b) ataque do CON, (c) arbitro neutro emite
     `VEREDITO_MOTIVO: VALID|INVALID|PARCIAL <conf 0-100>`;
  4. Sintese por contagem de VALID/INVALID/PARCIAL + veredito final motivado
     pelos motivos VALID. Uma divergencia agregada so e' aceita se pelos menos
     um motivo CON central for INVALID.
Nao basta "PRO disse SUBMIT-LOW, CON disse NAO, arbitro decidiu". Tem que
conferir cada 'pq' — se algum motivo principal do CON ficou sem rebuttal ou
sem VALID/INVALID explicito, o veredito e' INCONCLUSIVO mesmo que o arbitro
tenha dado label. Isso falhou na revisao coindcx BFF v3 (painel NIM deu
'DIVERGE' mas debate deep com 28 motivos mostrou 10 PRO VALID vs 1 CON VALID +
2 CON INVALID — o que realmente significa SUBMIT-LOW justificado). Label do
script NUNCA basta; ler o conteudo motivo-a-motivo.

CONVERGENCE GATE (strict): CONFIRMED only on consensus — both sides SUBMIT at
the same severity, OR a double concession. PRO=SUBMIT + CON=CONCEDO (one-sided
surrender) = DIVERGE = RETAINED, goes to operator. Surrender is NOT approval.
Report it EXACTLY: "technically defensible, no adversary sustains rejection,
but the formal gate never converges because CON concedes instead of
approving." Never call that "convergido". Surface CON's named alternative-
closure risk verbatim. See `references/reading-mas-output.md`.

## READ THE CONTENT, NOT THE LABEL (two silent-failure traps)

The adversarial harness can report the WRONG verdict from a parsing bug —
twice confirmed. Always open the transcript and read the ACTUAL positions.

1. **MAS label-parse bug (2026-10-02, CoinDCX BFF v3).** The script printed
   `CONVERGIDO=False | divergem: CON=NAO-low`, but the CON agent's real
   `POSICAO_FINAL` was `CONCEDO-convergencia ... SUBMIT-low e a posicao
   honesta`, the panel logged `GATE iMAD: divergencia material? False`, and the
   blind arbiter declared consensus at 90%. The regex grabbed a `NAO-low`
   fragment from a DUPLICATED re-ask template (7 `POSICAO_FINAL` lines from
   echoed prompts). Same class as the `loop_decide` parse_plan greedy-regex
   bug. ALWAYS grep the transcript for the LAST real `POSICAO_FINAL` per side +
   the `GATE iMAD` line + the arbiter `VEREDITO`/`CONFIANCA`, judge from those.
2. **PRO=SUBMIT / CON=CONCEDO is DIVERGE, not consensus.** The formal gate is
   right to fail-closed; do not override into "convergido". But also do not
   misread a genuine double-SUBMIT/double-CONCEDO as DIVERGE because the parser
   choked — trap 1 is why you read the content.

General rule: for ANY per-artifact verifier (panel label, lint, relive
script), trust the transcript/body over the summary line, cross-check an
invariant.

3. **CONCEDO-nenhum is a SUSTAINED position, not a surrender (2026-10-15,
live on cases-cross-user cycle 3).** The CON agent filled the
`CONCEDO-<motivo>` template slot with `CONCEDO-nenhum (mantive a posição
original pois o adversário não refutou os fundamentos essenciais)` — i.e. it
used the concession template to say "I concede NOTHING, I kept my position".
The parser read `CON=CONCEDO/?` (surrender) and the run header printed the
false-positive direction: a technical-approval-that-wasn't. I (the same
session) misrecorded it in the ledger as "rendição-com-endosso" before
reading the full transcript. Rules: (a) any nothing-conceded marker
(`nenhum|nada|zero|N pontos`) or position-kept marker (`mantive a posi[çc][ãa]o`)
inside a CONCEDO verdict means the position is SUSTAINED = NAO at the last
known severity — read the transcript for it; (b) the CON's cycle-1/cycle-2
positions carry that severity (`NAO-medium`), so the sustained read is
unambiguous; (c) a REAL surrender reads `CONCEDO-convergencia ... SUBMIT-low`
or `CONCEDO-<the point being dropped>` with no negation-of-content.
Countermeasure implemented: `norm_verdict` strips the `POSICAO_FINAL:` prefix
before positional guards, treats nothing-conceded as NAO, and
`N/A-Informative`-as-position parses NAO — regression suite 22/22 (3 new
cases pinned). Do not re-derive surrender from the word CONCEDO alone.

## AUTO-ESCALONAMENTO lite -> deep (2026-10-12, ligado no report_queue.py)

O metodo DEEP (Step 5, motivo-a-motivo) nao e mais so manual. O pipeline de
validacao (`~/tools/T3MP3ST/report_queue.py`) agora o executa numa ETAPA
AUTOMATICA:

- `run <eng> <file> --tier deep` roda `mas_adversarial_deep.py` direto.
- **AUTO-ESCALA**: rodando no tier barato (lite) e o veredito DIVERGIR, o
  report_queue roda o DEEP em sequencia automaticamente — desde que
  `quota.level == 'ok'` (senao queimaria o teto NIM 40rpm). O ledger marca
  `escalated_deep: true` e `note` diz "auto-escalado p/ deep".
- Desligar por tick: `REPORT_NO_AUTO_DEEP=1` no env do job.
- Parser do deep LE o `verdict.json` (recommendation: SUBMIT |
  NAO-SUBMIT-ATE-CONVERGIR + contagem VALID/INVALID/PARCIAL), nunca o label
  do stdout. Sem verdict.json = fail-closed (NAO).
- Quota `hard` rebaixa deep->lite automaticamente (mesma regra do full).

Regra de leitura continua valendo: mesmo com `recommendation=SUBMIT` do deep,
conferir o SYNTH.md — uma divergencia agregada so e aceita se >=1 motivo CON
central vir INVALID (senao INCONCLUSIVO mesmo com label SUBMIT).

### FAIL-OVER do deep: provedor externo morto (licao 15/10, AUTOMATIZADO 16/10)

O `debate_deep.sh` agora faz o fail-over SOZINHO (patch 16/10): probe barato
(`ask.py --budget 200`) no boot; token Claude morto -> o debate INTEIRO roda em
GPT-6 (`codex exec`), carimbado `Mode: GPT-only same-family` no SYNTH.md. A
validacao `FAILOVER_OK` foi testada ao vivo 16/10 (coindcx-gql). Regras de
leitura do deep GPT-only:

- MODO INFERIOR: same-family PRO-vs-CON e mais fraco que cross-engine — um
  veredito SUBMIT do deep GPT-only PRECISA de contraprova externa (NIM painel
  ou operador) antes de contar como S5. Um RETIDO/NAO do deep GPT-only e
  INFORMATIVO forte (o lado CON GPT-6 sustentou) mas nao fecha sozinho.
- CUSTO REAL MEDIDO 16/10: debate motivo-a-motivo consome a quota diaria do
  codex (~22k tokens/motivo; inventario de 48 motivos consumiu o dia). Deep
  GPT-only e LIMITE-DIA: no maximo ~25 motivos/debate. Se o inventario listar
  >25 motivos, puxe so os CENTRAIS (severidade/impacto/eligibilidade) e
  enfileire o resto — inventario de 48 motivos e cheiro de fragmentacao
  (cada nit de redacao virou motivo).
- TRAP de INVENTARIO (2 bugs ao vivo 16/10, corrigidos no debate_deep.sh):
  (1) saida truncada por `tail` comia os primeiros motivos (inventario
  comecou no p13); (2) contagem por `grep -c` + `seq 1..N` assume indices
  contiguos -> lado PRO INTEIRO silenciosamente pulado. Agora extrai os
  INDICES REAIS do arquivo (grep -oE '^- p[0-9]+:'), e motives_raw grava
  saida completa (tail generoso). Sempre conferir `pro_indices=[...]` != vazio
  no log do debate.
- QUOTA GPT MORREU NO MEIO: nao re-rode do zero — os vereditos por motivo ja
  gravados (/tmp/tri-review/deep-*/\*_arbiter.md) SAO a analise; leia os
  VALID/INVALID direto do disco e registre veredito parcial carimbado
  (ex 16/10 coindcx-gql: 24 VALID + 2 PARCIAL + 0 INVALID = CON sustenta;
  retry 08:30 quando a quota reseta).
- Probe barato ANTES de declarar qualquer provedor morto continua valendo
  (`echo "ping" | codex exec ...`, ~5s). So o lado morto e' pulado.

## FLEET LIVENESS (do this BEFORE launching any panel, or it runs empty)

- **Auto-selection is now built in (2026-10-03).** `mas_adversarial.py` calls
  `fleet_liveness.pick_live()` at the start of `main()` (lazy — import does NOT
  probe, so the parser/tests stay fast). It probes every judge with high budget,
  excludes DEAD/ERROR models, and picks live agents + a distinct live arbiter.
  The run header prints exactly which fleet was chosen and why:
  `[mas-adv] frota: agentes=... arbiter=... | fonte=auto-probe (kimi:DEAD ...)`.
  `MAS_ADV_AGENTS`/`MAS_ADV_ARBITER` still override (loop/operator wins). Tools:
  `fleet_liveness.py` (CLI `--pick N`, lib `probe_fleet`/`pick_live`).
- **Never declare a reasoning model dead from a low-max_tokens ping.** NIM
  reasoning models emit `reasoning_content` FIRST, `content` after. A ping with
  `max_tokens<=40` returns `content=null, finish_reason=length` — a FALSE
  negative. `fleet_liveness` probes with `max_tokens>=3000`; genuinely dead =
  `finish=stop` with empty `content` under high budget (kimi-k3 on 2026-10-03).
- **Stale static DEAD sets are the OTHER failure mode — they killed validator01
  (2026-10-03).** `panel_mas.py` has a hardcoded `DEAD` set that hard-refuses
  with RC=2. A stale note ("nemotron-super 410 Gone") banned a model that had
  RECOVERED (4.3s, finish=stop, 2356ch on a real long prompt), while the default
  agent list still contained kimi-k3 which had actually DIED. `fleet_liveness`
  selected the recovered model as alive, the panel refused it, `mas_adversarial`
  read RC=2 as a transport error and retried the SAME models 24× until the cap —
  burning quota, never converging. Fix: `pick_live()` now imports and RESPECTS
  `panel_mas.DEAD` (never hands the panel a banned model), and the DEAD set +
  `DEFAULT_AGENTS` were re-aligned to the live probe (kimi in, nemotron-super
  out). The live probe is the source of truth; keep `panel_mas.DEAD` matching
  the last probe. If a run logs repeated "erro de transporte" with 0 `(erro
  HTTP` in the transcript and NO new `/tmp/mas_adv_*.md` files, suspect a
  panel RC!=2 refusal (DEAD-set drift), not a network issue — run
  `python3 panel_mas.py ... --agents <picked>` directly and read stderr.
- **A reasoning model mid-thought looks identical to a dead one.** glm-5.3 took
  110s to first content; do not kill a MAS run "stuck" 20-40 min in one cycle.
  Track the real detached PID with `ps` (`process wait` on the `&` launch
  shell lies). A judge returning `verdict:ERROR` (read timeout) is neither
  clean nor a defect — the picker drops it for THIS run (flaky != dead).

## EXTERNAL ANGLE (use proactively when available)

- GPT/Codex: `codex exec --skip-git-repo-check --model gpt-5.6-sol
  --sandbox read-only - < prompt.txt`. Daily quota resets ~morning; if the log
  echoes the prompt with "usage limit", quota is spent (not a refusal) — record
  and reintegrate next day.
- Opus submission-critic ladder (v3): opus-4-8 → 5-5 → arbiter, one attempt
  per slug. Treat `submit:false` as binding unless new evidence refutes it.
- Strix OSS as an independent-harness second opinion for OpenAPI-spec targets.

## RED-LINES (never crossed by this gate)

The gate decides SUBMITTABLE; the OPERATOR decides SUBMIT. The actual H1
submit / OTP / captcha / program message is an operator red-line regardless of
how many layers cleared. Shared-attribution surfaces use SYNTHETIC identifiers
only. Impact on own account only.

## WORKED EXAMPLE (CoinDCX BFF v3, 2026-10-02 — the session that produced this)

Step 0 relive: control 403 → secret 200 → one-char 403 → protected paths 403
(exact-match gate). Step 1: all 7 evidence artifacts existed and agreed
byte-exact. Step 4: indefinite rotating review (kimi/gemma4/diffusiongemma/
nemotron + Opus) found 8 REAL defects across rounds (oracle staging
contradiction, PoC missing status code, over-strong "kept no data" vs saved
body-heads, local paths not attachable, "once per block" > evidence,
affected-assets dispute, oversized title, rule-of-three AI tell) — all fixed,
~14 false positives discarded against disk; three independent judges then
returned DONE/clean. Step 5: fresh MAS on the corrected draft CONVERGED
SUBMIT-Low (PRO=SUBMIT-low, CON=CONCEDO...SUBMIT-low, GATE iMAD material=False,
blind arbiter 90%) — the FIRST convergence after 3 prior DIVERGE runs on older
drafts, because the source-level X-Allow-Id proof had since been added. The
script label falsely said DIVERGE/NAO-low; reading the transcript (trap 1)
revealed the real consensus. Honest residual surfaced to operator:
N/A-Informative tail if a triager frames the gate as abuse-filter over public
data.

## REPORT-VALIDATION QUEUE + NIGHTLY ORCHESTRATION (2026-10-06, operator)

The `engagement-status-tick` only REPORTS; it does not validate. A separate
nightly validator picks reports that are NOT yet submittable and runs the gate
on them, rate-limit-aware, in a quiet window.

- `~/tools/T3MP3ST/report_queue.py` — the queue. `scan` / `nonready` find
  report candidates in ACTIVE engagements (from jobs.json) that lack
  `submit_ok`; `next` picks the next round-robin; `run <eng> <file> [--tier
  lite|full]` runs the tier (lite = `mas_lite.py`, full = `mas_adversarial.py`),
  parses the verdict from the CONTENT (never the label), and records it.
  Ledger: `~/tools/T3MP3ST/report_ledger.json`.

### Portfolio reportability inventory

Use this procedure whenever the operator asks what is reportable/submittable
across several engagements. This is a READ-ONLY inventory pass, not permission
to skip the gate and not a reason to re-run expensive panels on every draft.
Use the validation already on disk; run the full gate only on the item selected
for a fresh go/no-go.

1. Run `loop_state.py list`, `report_queue.py scan`, and `report_queue.py
   nonready`. State both the number of candidate ARTIFACTS and the number with
   `submit_ok=true`; never call artifact count a finding count.
2. Supplement the queue with a recursive inventory of every active
   engagement's `reports/**/*.md` plus submit-class actions/claims in its
   state. The queue can contain old versions and may omit nested report
   directories, so it is not a complete portfolio index by itself.
3. Deduplicate by finding lineage/topic. Keep the newest applicable draft;
   park superseded, gated, refuted, record-only, and older `v1/v2/FINAL`
   variants rather than counting them as separate findings.
4. For each unique candidate, read the CURRENT draft, latest S0 replay, policy/
   scope capture, duplicate check, adversarial transcript, and ledger entry.
   Compare draft hash/mtime with the artifact validated by the gate. A verdict
   over older bytes does not green-light a materially edited draft.
5. Reconcile machine and human state explicitly. `submit_ok=false` beside prose
   saying "submit-ready" is a discrepancy to resolve, not permission to
   silently promote; likewise, a parser label never overrides transcript
   content. Classify the item as reconciliation-required until exact-draft
   evidence agrees.
6. Keep four output classes distinct: **strict-green/submittable**,
   **technically credible but objectively blocked**, **retained/diverged**, and
   **record-only/refuted/superseded**. `reportable` may include the second class
   with the blocker named; `submittable` means only the first.
7. Verify submission separately with a durable HackerOne report ID/receipt.
   A filename, an open submit action, or absence of a matching receipt filename
   is not proof of submission state.
8. Answer in operator order: strict headline first, prioritized table
   (finding, proposed severity, strongest evidence, exact blocker), then
   low-value VDP/Informative candidates, then non-reportable items, and end
   with the single highest-leverage unlock. Do not replay the filesystem walk.

Detailed commands, normalization fields, and the decision table are in
`references/portfolio-reportability-inventory.md`.

- Rate-limit awareness: `report_queue.py quota` reads the signal the Gateway
  Error Fixer publishes to `~/.hermes/cron/quota_state.json` (level ok/soft/
  hard from the RECENT journal tail window). soft -> lite only; hard -> skip.
  The error-fixer notice reaches the validator by (a) that JSON and (b) the
  validator's own context script, which refreshes the quota fresh each tick.
  **STALE-SIGNAL TRAP (2026-10-09)**: the error-fixer itself can fail for hours
  (its own agent turns 429) and leave quota_state.json frozen at `hard` from
  BEFORE a gateway restart. `quota()` now computes `age_min` + `stale`; a signal
  >30min old must be cross-checked against the live journal (429 count under
  the CURRENT gateway PID) before obeying soft/hard. A stale `hard` does NOT
  block validation; a fresh one does. Symptom seen: file said hard@01:41 UTC,
  journal showed 0x429 in 6h of the new PID, error-fixer 9 failures in a row.
### Arbiter-independence rule for the LITE tier (2026-10-09 — fixed live)

The lite's manual fleet selection reused a JUDGE as the blind ARBITER when the
live pool had only 2 models (observed: PRO=lightning + ARB=lightning on the
cases-cross-user gate — the arbiter judged the case its own PRO self had
argued; blindness broken silently). The independence logic already existed in
`fleet_liveness.pick_live` (the 2026-10-04 fix) but mas_lite had its own older
copy. Fixes, all tested (2-vivos -> RETIDO fail-closed with 0 NIM calls;
degraded mode allowed only via `MAS_LITE_ALLOW_DEGRADED=1` and then the reason
is SANITIZED — the string `consenso submit` must never appear in stdout when
the gate refused it, or `report_queue._parse_verdict` regex reads false
consensus):
1. Lite needs 2 judges + 1 arbiter = 3 INDEPENDENT roles. With exactly 2 live
   models that is impossible: default is RETIDO fail-closed + escalate to
   `mas_adversarial.py` (full). Never silently reuse a judge as arbiter.
2. `MAS_LITE_ALLOW_DEGRADED=1` runs anyway for an INFORMATIVE verdict, but a
   degraded run can NEVER yield `submit_ok` (structural: `consenso_submit and
   not degraded`) — the reused arbiter already saw the case as a party.
3. Parser-sync discipline: when a gate blocks a verdict, the blocked REASON
   string must not contain phrases the downstream parser matches on. Sanitize
   the reason, don't just prefix a stamp.
4. Root pattern (3rd instance): parallel copies of convergence/selection logic
   drift — mas_lite selection vs pick_live was the same bug class as the
   verdicts_agree reimplementation. RULE: the lite imports the full tier's
   logic; when the full tier gains a selection/independence fix, port it the
   same day or delete the copy.

### Queue-serializer bug (2026-10-09)

`report_queue.nonready()` returned records carrying internal keys (`_topic`
frozenset, `_mtime_ts`); `json.dumps` in `next`/`nonready` crashed with
`TypeError: frozenset is not JSON serializable` — the nightly validator could
not pick ANY report (symptom: `next` exits non-zero while `scan` works). Rule:
public-facing lists must strip underscore keys before serialization. Fixed by
stripping `_*` in `nonready()`.

### Queue hygiene, deterministic, BEFORE spending any NIM call (2026-10-09 —
  cut phantom queue from 25 to 12):
  1. **Superseded-filter**: keep only the LATEST mtime per topic family
     (regex TOPIC_RX) per engagement. Essity had takeover v1/v2/FINAL/v3/v4 +
     CORS v1/v2/FINAL/v3 queued = ~27 wasted NIM calls on dead drafts.
  2. **Self-declared gate (AFTER the superseded-filter, never before)**: skip
     reports whose own header says SUPERSEDED / GATED / NAO-PRONTO / ENCONTRADO
     NAO EXPLORADO. Order matters: if the latest version of a topic is gated,
     the whole topic is PARKED — applying the gate first resurrects old
     versions (observed: cors-FINAL 09-01 came back when v3-GATED was dropped).
  3. **False-exclusion regex trap**: EXCLUDE_RX `message-to` matched substring
     in `postmessage-to*ken*` and hid the okto-3p-widget draft from the queue
     for days. Tightened to `message-to-(h1|program|owner|essity)`.
  4. **Pending-experiment drafts (2026-10-09b)**: a draft describing an
     experiment that was NOT yet executed ("pre-mapeamento pós-OTP",
     "POS-OTP", "aguardando GO") is not a submission draft — validating it
     burns NIM rounds on a claim with nothing on disk to check. The
     self-declared gate now parks those headers too (observed:
     serverless role_assignments request-draft, nebius xfh-307 parked; queue
     12 -> 10). A scope-CUT legacy draft (elastic connector-ssrf, class closed
     by operator decision 09-25) initially only surfaced to the operator;
     refined same night: parked WITH a `STATUS: GATED - <decision + date +
     reopen condition>` provenance header in the draft itself — attributable,
     reversible via GO, visible in every future read, and stops the per-tick
     NIM burn on an already-decided class. Park-with-provenance beats both
     silent parking and endless re-surfacing; the summary must always tell the
     operator which drafts were parked and why (queue 10 -> 9).
  5. **Drafts must cite the exculpatory negative experiments they already own**
     (2026-10-09b): against the Kibana cases BOLA, the CON's only surviving
     objection was "no cross-space/production demonstrated" — while
     `reports/a1-crossspace-negative.md` (3 routes tested WITH a positive
     sanity control, space filter survives) sat on disk uncited. The
     systematic negative is doubly valuable: it answers the inflation
     objection AND demonstrates diligence, keeping severity honest (Medium).
     Fix pattern: grep the engagement's `reports/`+`evidence/` for experiments
     related to every "not demonstrated" phrase in a draft BEFORE running any
     panel; if a negative result exists, cite it explicitly instead of leaving
     the gap implied.
- Parser hardening (2026-10-09): `consenso claro: NAO` parsed as submit_ok=True
  (the same substring-trap class Opus found in norm_verdict on 10-03) —
  consensus must carry a DIRECTION (submit) and a contra-guard rejects
  consensus-of-NAO and endorsement-of-rejection. Cross-run contamination:
  the evidence-dir glob rescue pulled the PREVIOUS report's verdict
  (SUBMIT-high of pentest-report) into the writeup run — stdout of the OWN run
  now wins whenever it carries verdict markers.
- Fleet fit for the LITE tier (2026-10-09): the PRO judge gets the whole draft
  in-prompt. deepseek-v4.1-flash blew the 240s read-timeout on a 22KB draft
  (pure transport fail, RETIDO fail-closed, no merit verdict); glm-5.3 handled
  it. Match judge size to draft size; on transport-error re-run once with a
  different PRO slug (env MAS_LITE_PRO) rather than escalating to full.
  nemotron-3.5-lightning PRO degenerated mid-response (word-salad with quota
  OK) on a 12KB draft — one occurrence, watch it; degeneration = swap model,
  not retry.
- Nightly orchestration (cron jobs, all delivered to Telegram):
  `Kimi-k3` is the primary model for the validator and the engagement loops
  (operator 2026-10-06); the global `fallback_providers` chain is
  `z-ai/glm-5.3` then `z-ai/glm-5.3-flash`, and the cron scheduler passes that
  chain to every job agent. Note kimi-k3 is slow (~100-120s/call), so a full
  validation can take many minutes — that is why the validator runs alone in
  the quiet window.
  `Nightly Pause` (02:55, script-only) pauses the routine LLM ticks
  (Curiosity Loops, engagement-status, Output Analyzer, Provider Scout) so the
  window has the NIM budget to itself; `Report Validator (noturno)` runs
  `0-59/10 3-6 * * *` (fires only inside the window); `Nightly Resume` (07:00,
  script-only) VERIFIES they were unpaused and unpauses any that were not.
  The pause writes a resume_set + arms a DETACHED watchdog (setsid) so the
  resume is guaranteed even if cron tree-kills the pause
  (`nightly_pause.sh`/`nightly_resume.sh`/`nightly_watchdog.sh` in
  `~/tools/T3MP3ST/`). Keep the pause list an explicit name allowlist — a
  "pause everything except X" form would pause the orchestration jobs
  themselves and wedge the chain.
- Self-improvement trigger: when the validator discovers a better validation
  method (new live model, cheaper technique, a validator bug), it reports AND
  updates THIS skill (via skill_manage) after testing the idea.

## LESSON-CAPTURE HABIT (2026-10-12, operator: jaunt lessons so the same trap never repeats)

Every time a session is slowed, blocked, misled, or nearly produced a wrong
conclusion, add it to the embedded-lessons skill of its domain — this is how
the fleet stops repeating traps:

- **loops / cron / gateway** -> `system/loop-operations-lessons` (pause/resume,
  restart killing in-flight ticks, 429 vs dead model, fake exhaustion,
  evidence guard, zombie re-proposals, "what is left unexplored" pass).
- **findings / triage / submission** -> `cybersecurity/pentest-anti-false-positive-lessons`
  (read CONTENT not LABEL; negative controls and no-op mutations; WAF-403 vs
  authz; informative vs ineligible; logged policy as source of truth;
  cross-run contamination).
- **bug / regression debugging** -> `software-development/diagnosing-bugs`.
- **method-level bug in this gate** -> CHANGELOG below.

Rule: a lesson is only captured if it states (a) the symptom, (b) the real
cause, and (c) the countermeasure. "Be careful" is not a lesson.


### Deterministic evidence lint (2026-10-12) — advisory, wired into report_queue

`~/tools/T3MP3ST/evidence_lint.py <report.md> [--json]` codifies the
AUTOMATABLE traps from `pentest-anti-false-positive-lessons` as regex checks:
impact-without-artifact, no-negative-control, mutation-without-nonidentity-guard,
waf-403-vs-authz, map-without-territory, bare-version-or-date,
cross-run-contamination, inconclusive-vs-negative, secret-in-report.

It is ADVISORY (never changes a verdict). `report_queue.py run` now runs it and
stores `lint` in the ledger entry + a `evidence_lint: N warn` note. Calibration
>= noise: on the local report corpus it flagged the real mutation/impact traps
and stayed clean on the good drafts (a false positive on BFF v3 — "change one
character returns 403" is a valid non-identity proof — was fixed by accepting a
differential-result phrasing). Treat every hit as "verify this", not "reject".

## CHANGELOG

- v1.4.4 (2026-10-16) — Fail-over AUTOMATICO no debate_deep.sh (probe no boot;
  Claude morto -> debate inteiro em GPT-6, SYNTH carimbado `Mode: GPT-only
  same-family`). Validado ao vivo no coindcx-gql. Custos/traps medidos: ~22k
  tokens/motivo no codex (quota diaria = ~25 motivos), inventario de 48 motivos
  = fragmentacao; 2 bugs de inventario corrigidos (tail truncava primeiros
  motivos; grep -c + seq assumia indices contiguos -> lado PRO pulado em
  silencio). Quota GPT morta no meio: ler vereditos por motivo do disco e
  registrar parcial carimbado (24 VALID + 2 PARCIAL + 0 INVALID = CON sustenta).
  Tambem neste tick: fecho deterministico de report com full ja convergido +
  edit ADITIVO posterior — a validacao NAO re-roda se a unica pendencia era
  redacao (AI-lint 23 em-dash -> 0 no ds1; S4 fechado, zero NIM).

- v1.4.3 (2026-10-15) — Deep fail-over GPT-only (live on okto-3p draft):
  `debate_deep.sh` hard-depends on `ask.py` (Claude OAuth) and dies WHOLE when
  the Claude token expires — even though the GPT-6 side is alive. Probe both
  sides cheaply first; if Claude is dead, run the manual debate with
  `codex exec --model gpt-6-astra` on BOTH sides (CON hostile → PRO answering
  the attacks point-by-point → content read). Two same-run traps, both hit and
  fixed: (1) the CON attack text MUST be persisted to a file BEFORE building
  the PRO prompt or the PRO defends against nothing; (2) the divergence
  CON=NAO-low + PRO=CONCEDO-low is NOT the BFF-v3 "technical approval" pattern —
  here BOTH sides agree the current impact is not eligible and the gap is the
  deliverable (trust-boundary proof, real session capture, or honest
  Low-hardening reframe). Verdict reading never changes: read POSICAO_FINAL
  content, not script labels.
- v1.4.2 (2026-10-15) — Parser trap 3 (live on cases-cross-user):
  `POSICAO_FINAL: CONCEDO-nenhum (mantive a posição original...)` is a
  SUSTAINED position (nothing conceded), but `norm_verdict` read CONCEDO =
  surrender → false "technical approval". Fix: nothing-conceded markers
  (nenhum/nada/zero/N pontos) + position-kept markers inside CONCEDO → NAO;
  `POSICAO_FINAL:` prefix stripped before positional guards; `N/A-Informative`
  as final position parses NAO. Regression suite 19→22 (3 new cases pinned).
  Same-run note: mas report header must not be trusted either — cycle 3
  printed "CON=CONCEDO-nenhum" in the per-cycle line and only the transcript
  showed the sustained-position parenthetical.
- v1.4.1 (2026-10-15) — Step 0 PUBLIC-PARITY CHECK (tested live): for "hidden/
  behind-login" claims, render every plausible public route in the JS browser
  (CDP 9222) before any panel. First live catch: coindcx referral-rewards draft
  refuted at Step 0 (public landing /en/page/referral-program renders the same
  6-level table anonymously; the draft's control had tested the wrong route
  /en/referral-program). Also encoded: non-JS fetcher text (curl/Jina) is not
evidence of what an SPA shows; closed N/A-by-design claims with positive
controls are hard precedents a new draft must address; CF-403-on-curl !=
  auth-required; one wrong-route control proves nothing. Saved 3+ NIM calls
  and a certain N/A-Informative submission.
- v1.4.0 (2026-10-12) — MANDATORY DEEP MODE: debate ponto-a-ponto motivo-a-motivo
  com inventario numerado (PRO1...N, CON1...N), cada motivo passa por defesa,
  ataque e arbitro com veredito VALID/INVALID/PARCIAL por-motivo. Veredito final
  pende dos motivos VALID. Harness: `mas_adversarial_deep.py` (wraps
  `mas_adversarial.py` + `debate_deep.sh`). Substitui "cross-debate 1 round",
  que era superficial reading de posicoes. Operador: "quero que discutam sobre
  cada coisa proposta ate que entrem em um consenso". Report-validations NIM lite
  modes sao só filtro — o gate final e' DEEP.
- v1.3.2 (2026-10-09b) — Lite arbiter-independence fix (judge-as-arbiter when
  pool=2; RETIDO fail-closed default, MAS_LITE_ALLOW_DEGRADED=1 informative
  only, reason sanitized so no false `consenso submit` reaches the parser);
  report_queue serializer fix (frozenset `_topic` crashed `next`/`nonready`,
  queue was unpickable); pending-experiment headers added to the self-declared
  gate (12 -> 10 real candidates).
- v1.3.1 (2026-10-09) — Queue hygiene hardening from live validator runs:
  stale-quota trap (age/stale flags, live-journal cross-check), superseded +
  self-declared filters in the correct order (25 phantom candidates -> 12
  real), message-to false-exclusion fix, consensus-direction parser fix
  (consenso-claro-NAO no longer parses as submit_ok), cross-run contamination
  guard (own-run stdout wins over evidence glob), lite-judge size-fit lesson
  (deepseek read-timeout on 22KB; lightning word-salad on 12KB).
- v1.3.0 (2026-10-06) — Added the report-validation queue +
  nightly orchestration (report_queue.py, nightly pause/resume/validator jobs,
  rate-limit signal from the Gateway Error Fixer). See the section above.
- v1.1.0 (2026-10-03) — SELF-VALIDATED. Ran the gate's own Step 5 (adversarial
  MAS) against this skill as the subject (validator01). Fixed 3 infrastructure
  defects that had been silently breaking the panel: (a) fleet now auto-selects
  live judges at panel boot via `fleet_liveness.py` (the fixed `kimi,gemma4,
  lightning` default was running a dead model and looping on transport errors);
  (b) `panel_mas.py` stale static DEAD set realigned to the live probe and
  `pick_live` now respects it (a recovered model was being hard-refused, RC=2
  read as transport error, 24x retry); (c) `last_final` parser hardened against
  the self-reference trap (a doc quoting `[árbitro`/`POSICAO_FINAL` as text made
  the zone-cut grab the prompt echo instead of the real verdict) — regression
  now 7/7. Then the panel named a CONTENT hole both sides agreed on, which
  became Step 3.5 (freshness: scope-still-active + embargo window). The method
  improved itself: diverge-with-material-gap is a finding, not a failure.
- v1.2.0 (2026-10-03) — Recursive self-run on v1.1.0. Panel AGREED Step 3.5
  closed the freshness hole (PRO conceded "no material gap"), then named a
  deeper one: every live read trusts `:9222`/DOM without proving the response
  is fresh and un-tampered (cache/304/proxy injection). Added the transversal
  channel-integrity rule (cache-buster + fresh-200 + API-over-DOM + anti-stale
  marker) to Steps 0/3/3.5 — a read without a freshness proof is UNVERIFIED and
  blocks submittable. No extra panel round. Also split the gate into a LITE
  automatic tier (loops, cheap) vs the FULL manual tier (operator-triggered).

## TWO TIERS (cost vs rigor — operator directive 2026-10-03, NIM 40rpm ceiling)

- FULL (`mas_adversarial.py`, MANUAL): indefinite PRO-vs-CON rounds x 3-judge
  quorum per side + blind arbiter, to strict convergence. ~16+ NIM calls/cycle.
  The operator triggers it for the final seal on a submission. In the loop set
  `LOOP_ADV_FULL=1`.
- LITE (`mas_lite.py`, AUTOMATIC in loops): 1 PRO judge + 1 CON judge + 1 blind
  arbiter, single pass, SAME strict convergence criterion (it imports
  `verdicts_agree` from the full tier — never a parallel copy). 3 fixed NIM
  calls; fits the ceiling. Fast-path: pass `MAS_LITE_PRO/CON/ARB` to skip the
  liveness probe (the loop probes once/tick). If LITE diverges it prints
  ESCALAR and `adversarial_gate` sets `escalate=True` for the operator to run
  FULL. LITE is a cheap high-coverage filter, NEVER the final seal; it never
  auto-submits (operator red-line intact).

### Self-audit lessons (2026-10-03 — I reviewed my own lite build and found 8 real bugs)

A lightweight copy of an adversarial gate is where false-submits hide. What a
hostile self-review of the implementation must check (all 8 were live defects):
1. Convergence parity: the lite MUST reuse the full tier's `verdicts_agree`,
   not a reimplementation — a hand-copied version dropped the inverse-endorsement
   case and diverged from the full verdict.
2. `submit_ok` derivation: true only when converged AND the agreed side is
   SUBMIT; double-concession converges but is NOT submit.
3. Transport error != divergence: a judge returning an error string parses as
   `?` and would print a FALSE diverge. Detect the error, mark RETIDO
   fail-closed, never a misleading verdict.
4. Fast-path env slugs must be validated against the model CATALOG or a typo
   KeyError-crashes the gate; fall back to probing.
5. The blind-arbiter veto must normalize ALL non-submit forms ("NAO-medium",
   "NAO SUBMIT", "NO-SUBMIT", "NOT", illegible), not just the exact literal.
6. A naive `"SUBMIT" in verdict` test reads the arbiter's own contract word
   "NAO-SUBMIT" as SUBMIT (substring trap) — guard negation markers first.
7. Lazy fleet resolution so importing the module for its logic never probes.
8. Fail-closed everywhere: any error/ambiguity/illegible verdict blocks
   submittable rather than passing it. Reading the CONTENT over the label
   (the recurring trap) applies to your OWN tooling, not just the models.

### Opus 4.8 independent review (2026-10-03 — different model family, found 5 more)

After the self-audit I had Opus review the convergence logic as a neutral
correctness check (frontier Opus-5.5 refused the bug-bounty framing; Opus-4.8
is the context-tolerant fallback, reached via `~/tools/opus5/ask.py` — sync the
live token from `~/.claude/.credentials.json` into `~/.hermes/auth.json`'s
`credential_pool.anthropic[0]` first, it desyncs). Opus found the substring
trap living INSIDE the SHARED `verdicts_agree.norm`, which my self-audit had
wrongly dismissed as "not exposed":
- Bug B (CRITICAL, verified live): `norm("NAO-SUBMIT high")` returned SUBMIT
  because `"SUBMIT" in v` ran before the NAO check — a clear CON rejection read
  as submit-consensus, in the function BOTH tiers share. Fixed: negation guard
  first.
- Bug C (HIGH): the endorsement test `"SUBMIT" in text` had the same trap; a
  CON conceding but saying NAO-SUBMIT counted as endorsement. Fixed:
  `_endorses_submit` rejects negation markers.
- Bug E (MEDIUM): severity matched by free substring — `"NA"` matched inside
  FINAL/ANALISE/NAO and `N/A != NA`. Fixed: anchored `\b(HIGH|MEDIUM|LOW|N/?A)\b`
  + canonicalize N/A->NA.
- Bug A (CRITICAL-latent): `submit_ok` derived from the natural-language reason
  string, protected only by accident. Fixed: derive structurally from the
  normalized decisions via module-level `norm_verdict` (extracted so the lite
  reuses it, never a copy).
- Bug D (HIGH): transport-error detection by `startswith("(erro")` heuristic
  could fail-open if an error string lacked the prefix. Mitigated; the deeper
  fix (structured error sentinel from the API caller) is noted for next pass.
LESSON: "not exposed in practice" is not a fix — a hostile reviewer from a
different model family found what I rationalized away. An independent frontier
review of the CORE LOGIC is now part of the method's own hardening cycle.

