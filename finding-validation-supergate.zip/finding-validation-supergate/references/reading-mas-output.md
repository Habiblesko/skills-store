# Reading MAS / adversarial-panel output correctly

The `mas_adversarial.py` one-line label is NOT trustworthy by itself. Two
confirmed traps make it lie. ALWAYS read the transcript content.

## Why the label lies: transcript anatomy (decoded 2026-10-03)

A PRO/CON transcript has THREE zones, and `POSICAO_FINAL` lines appear in
ALL of them:
1. Echo of the advocate prompt (sometimes twice) — contains the literal
   template strings `POSICAO_FINAL: NAO-<...>` as INSTRUCTIONS, not positions.
2. The agent's own answer, which itself runs an INTERNAL sub-panel with
   positions A/B/C — each emitting its own `LACUNAS:` + `POSICAO_FINAL`.
   Multiple real-looking positions per file is NORMAL. The internal gate
   line `PRESERVADA vigente na rodada final: ['C']` names which one was
   actually sustained; `Gate: pulou debate (consenso: ...)` means the agent's
   internal panel reached consensus without debate.
3. A `[árbitro: ...]` block — the BLIND ARBITER, a DIFFERENT subject, whose
   own sub-panel ALSO emits `POSICAO_FINAL` lines.

So "the last POSICAO_FINAL in the file" is wrong twice over (can be the
arbiter's, or a template echo), and "the first substantive block" is wrong
too (can be internal position A, later overruled by C).

## The rule (FIXED in the parser — run the regression test after ANY edit)

**POSICAO FINAL REAL of an agent = the LAST `POSICAO_FINAL` BEFORE the FIRST
`[árbitro` marker.** Implemented in `last_final()` in
`~/tools/T3MP3ST/mas_adversarial.py` (zone-cut at first `[árbitro`, accent/
case tolerant), pinned by:

```bash
python3 ~/tools/T3MP3ST/test_last_final.py   # MUST print 6/6 PASS
```

Pinned cases:
- CoinDCX BFF v3 con2: real = `CONCEDO-low` (agent internal gate:
  `Gate: pulou debate (consenso: severidades=['low'])`). The `NAO-low` further
  down (line 303) belongs to the ARBITER's sub-panel — old parser read it,
  called the run DIVERGE; real verdict was consensus → SUBMIT-Low.
- Wolt refresh-token con2: real = `NAO-Medium` (position C preserved:
  `PRESERVADA vigente na rodada final: ['C']`). The old label said NAO-low —
  wrong about which subject held the position (that NAO-low was the
  arbiter's). DIVERGE stands either way, but attribution must be right.

## Trap 2: CONCEDO is not approval (but convergence can still be real)

- PRO=SUBMIT + CON=CONCEDO (surrender, no SUBMIT emitted) = DIVERGE,
  fail-closed, RETAINED to operator. Report as "technically defensible, no
  adversary sustains rejection, formal gate does not converge because CON
  concedes instead of approving." Never "convergido".
- PRO=SUBMIT + CON=CONCEDO...SUBMIT (CON concedes AND endorses submitting) OR
  both-SUBMIT OR both-NAO = real consensus. The label parser may still
  misreport this as DIVERGE (trap 1) — the transcript + GATE iMAD + arbiter
  are what decide.

## Save the transcript before the process is gone

`panel_debate`/MAS do not always persist a consolidated transcript. After the
run exits, copy the per-agent files into the engagement so the verdict is
auditable:

```bash
cp /tmp/mas_adv_pro2_a1_*.md ~/engagement-<eng>/loop/evidence/mas-adv-<draft>-pro2.md
cp /tmp/mas_adv_con2_a1_*.md ~/engagement-<eng>/loop/evidence/mas-adv-<draft>-con2.md
cp "$R" ~/engagement-<eng>/loop/evidence/mas-adv-<draft>-report.md
```
