# Portfolio Reportability Inventory

Use this recipe for portfolio-level questions such as “what is reportable?” or
“what can I submit now?”. It inventories existing validation; it does not turn
a draft into a validated finding.

## 1. Establish the portfolio

Start from live engagement state, not remembered engagement names:

```bash
python3 ~/tools/T3MP3ST/loop_state.py list
python3 ~/tools/T3MP3ST/report_queue.py scan > "$TMPDIR/report-scan.json"
python3 ~/tools/T3MP3ST/report_queue.py nonready > "$TMPDIR/report-nonready.json"
```

Summarize rather than dumping the queue:

```bash
python3 -c 'import json,sys; x=json.load(sys.stdin); print({
  "candidate_artifacts": len(x),
  "submit_ok_true": sum(bool(i.get("submit_ok")) for i in x),
  "statuses": {s: sum(i.get("status")==s for i in x)
               for s in sorted({i.get("status") for i in x}, key=str)}
})' < "$TMPDIR/report-scan.json"
```

`candidate_artifacts` counts files, not unique findings.

## 2. Prove inventory coverage

For every active engagement:

1. Recursively enumerate `reports/**/*.md`, including nested topic directories.
2. Inspect submit-class `next_actions`, live claims, and barriers in
   `loop_state.py get <eng> --summary`.
3. Read the matching entry in `report_ledger.json`.
4. Search for a durable submission receipt or HackerOne report ID.

Do not conclude “no report” from `report_queue.py scan` alone: scanners may
apply activity filters, filename filters, superseded filters, or shallow path
rules. Conversely, do not treat every Markdown file as a candidate; reports
directories contain negative controls, runbooks, policy audits, and old drafts.

## 3. Normalize and deduplicate

Create one row per finding lineage with these fields:

| Field | Meaning |
|---|---|
| engagement | Program/engagement owning the finding |
| topic | Stable finding family, independent of filename/version |
| current_draft | Newest applicable draft |
| self_status | Header markers such as GATED, SUPERSEDED, REFUTED |
| ledger_status / submit_ok | Machine validation state |
| s0_freshness | Timestamp and result of latest live replay + negative control |
| policy_freshness | Current scope, eligibility, embargo, program accepting |
| duplicate_check | Method, timestamp, and limitation |
| exact_draft_s5 | Whether Step 5 validated these exact bytes or only an older draft |
| route | Bounty, VDP, or out-of-program |
| blocker | One objective next step, not a vague “needs review” |
| receipt | Durable platform report ID/receipt, if submitted |

Deduplicate by topic, not filename. A lineage containing `draft`, `v2`,
`FINAL`, and `FINAL-v3-GATED` is one finding. The newest applicable status wins;
if the newest version is gated or superseded, do not resurrect an older one.

## 4. Read the evidence in the right order

For each unique candidate:

1. Current draft: asserted mechanism, impact, severity, limitations.
2. Latest S0 artifact: current live behavior and same-run negative control.
3. Current policy/scope/embargo capture with channel-integrity proof.
4. Duplicate-check artifact and its search limitation.
5. Adversarial transcript content, not just its summary label.
6. Ledger/state metadata, including the draft hash or mtime used by the gate.

If the draft changed after validation, diff the change. Purely editorial edits
can be closed deterministically; new facts, impact, severity, endpoints, or
PoC behavior require validation of the current bytes. Record the distinction.

## 5. Classification table

| Class | Required state | How to report it |
|---|---|---|
| Strict-green / submittable | Current S0, evidence audit, current policy/scope, hostile review, and strict S5 agree on the exact current draft | “Ready for operator copy-paste”; submission remains the operator red-line |
| Technically credible, blocked | Mechanism/impact has concrete evidence, but one named freshness/access/exact-draft gate is missing | “Reportable candidate after: `<one blocker>`” |
| Retained / diverged | PRO and CON remain materially split, transport degraded the run, or exact-draft S5 is absent | State both positions and do not call ready |
| Record-only / Informative | Differential exists but no protected data/action or eligible impact is demonstrated | Keep as evidence or VDP cleanup; do not imply bounty readiness |
| Refuted / superseded / gated | Live control disproved it, a newer version parked it, or policy/operator decision cut the class | Exclude from the submission queue and name the reason briefly |

A VDP finding can be technically reportable while having no bounty value;
show route/value separately from technical validity.

## 6. Resolve contradictions before promotion

Common contradictory states:

- `submit_ok=false` while free-text says “submit-ready”.
- A strict verdict exists, but it names an older draft hash.
- The report says “fresh” while the session/token needed for S0 is dead.
- A current bundle/secret/host drifted after the report was written.
- A report file exists, but its own first line says GATED or SUPERSEDED.

Do not choose the favorable side. Mark **reconciliation required**, identify the
single cheapest discriminator, and run it only when the operator selects that
candidate for go/no-go.

## 7. Verify submission state

Submitted means a durable platform report ID or receipt was read back. An open
`SUBMIT` action usually means not submitted, but it is not sufficient proof by
itself. If no receipt is found after searching the active engagement, say
“no receipt found in the inspected engagement”, not “never submitted”.

## 8. Response template

```markdown
Strict gate: X green; Y candidate artifacts (not Y findings).

| Priority | Finding | Proposed severity | Strongest proof | Exact blocker |
|---|---|---|---|---|
| 1 | ... | ... | ... | ... |

VDP / likely Informative:
- ...

Not reportable now:
- ... — reason

Highest-leverage unlock: ...
```

Lead with the strict state, then give the practical queue. This preserves the
difference between “a credible report exists” and “the current draft is safe
to submit now”.
